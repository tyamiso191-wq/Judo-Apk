package com.jarvis.ai.agents

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Google Gemini API geçidi (Google AI Studio anahtarı).
 *
 * Gemini'nin OpenAI uyumlu uç noktasını kullanır; böylece mevcut araç çağırma (function calling),
 * görsel gönderme ve mesaj biçimi aynen çalışır. Anahtar yalnızca isteğin Authorization
 * başlığında gider; loglara / hata mesajlarına yazılmaz.
 *
 * Anahtar almak için: https://aistudio.google.com/apikey
 */
class GeminiClient(
    private val keyProvider: () -> String?,
    private val http: OkHttpClient = defaultHttp()
) : ChatTransport {

    companion object {
        const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
        const val OPENAI_URL = "$BASE_URL/openai"

        /**
         * Sohbet modelleri, sırayla denenir. Google eski modelleri yeni kullanıcılara kapatabiliyor
         * (örn. gemini-2.5-flash artık 404 veriyor); biri kapalıysa ya da günlük kotası dolduysa
         * sıradakine geçilir.
         */
        val CHAT_MODEL_IDS = listOf("gemini-3.8-flash", "gemini-3.7-flash", "gemini-3.5-flash-lite")
        const val CHAT_MODEL_ID = "gemini-3.8-flash"

        private fun info(id: String) = ModelInfo(
            id = id,
            name = id,
            contextLength = 1_000_000,
            maxCompletion = 65_536,
            promptPrice = 0.0,
            completionPrice = 0.0,
            supportsTools = true,
            supportsReasoning = false,
            supportsImages = true,
            created = 0L
        )

        val CHAT_MODELS: List<ModelInfo> = CHAT_MODEL_IDS.map { info(it) }
        val CHAT_MODEL: ModelInfo = CHAT_MODELS.first()

        fun defaultHttp(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .callTimeout(150, TimeUnit.SECONDS)
            .build()
    }

    private fun requireKey(): String =
        keyProvider()?.trim()?.takeIf { it.isNotEmpty() }
            ?: throw LlmException(ErrorKind.AUTH, null, null, "Gemini API anahtarı girilmemiş.")

    override suspend fun post(body: org.json.JSONObject): RawResponse {
        val key = requireKey()
        val req = Request.Builder()
            .url("$OPENAI_URL/chat/completions")
            .header("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        return execute(req)
    }

    /** Anahtarın geçerliliğini, modelleri listeleyen hafif bir GET ile kontrol eder. */
    suspend fun validateKey(candidate: String? = null): KeyStatus {
        val key = (candidate ?: keyProvider())?.trim()?.takeIf { it.isNotEmpty() }
            ?: return KeyStatus.Invalid("API anahtarı boş.")
        return try {
            val req = Request.Builder()
                .url("$BASE_URL/models?pageSize=1")
                .header("x-goog-api-key", key)
                .get()
                .build()
            val raw = execute(req)
            val low = raw.body.lowercase()
            when {
                raw.code in 200..299 -> KeyStatus.Valid(
                    label = "Gemini", usageUsd = null, limitUsd = null,
                    limitRemainingUsd = null, isFreeTier = null
                )
                raw.code == 401 || raw.code == 403 ->
                    KeyStatus.Invalid("Bu Gemini anahtarı geçersiz ya da erişimi kapalı.")
                // Google, hatalı anahtara 400 "API key not valid" döndürür.
                raw.code == 400 && (low.contains("api key") || low.contains("api_key")) ->
                    KeyStatus.Invalid("Bu Gemini anahtarı geçersiz. aistudio.google.com/apikey adresinden yenisini al.")
                raw.code == 429 ->
                    // Anahtar geçerli, yalnızca kota dolu.
                    KeyStatus.Valid(label = "Gemini", usageUsd = null, limitUsd = null, limitRemainingUsd = null, isFreeTier = null)
                else -> KeyStatus.Unreachable("Gemini beklenmeyen yanıt verdi (HTTP ${raw.code}).")
            }
        } catch (e: IOException) {
            KeyStatus.Unreachable("Gemini'ye ulaşılamadı: ${Redactor.redact(e.message ?: "bağlantı hatası")}")
        } catch (e: Exception) {
            KeyStatus.Unreachable("Anahtar kontrol edilemedi: ${Redactor.redact(e.message ?: e.javaClass.simpleName)}")
        }
    }

    private fun retryAfterOf(resp: Response): Long? {
        val ra = resp.header("Retry-After")?.trim()?.toLongOrNull()
        return if (ra != null && ra >= 0) (ra * 1000L).coerceAtMost(10 * 60_000L) else null
    }

    private suspend fun execute(req: Request): RawResponse = suspendCancellableCoroutine { cont ->
        val call: Call = http.newCall(req)
        cont.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(e)
            }

            override fun onResponse(call: Call, response: Response) {
                try {
                    val text = response.use { it.body?.string().orEmpty() }
                    val retryAfter = retryAfterOf(response)
                    if (cont.isActive) cont.resume(RawResponse(response.code, text, retryAfter))
                } catch (e: IOException) {
                    if (cont.isActive) cont.resumeWithException(e)
                }
            }
        })
    }
}
