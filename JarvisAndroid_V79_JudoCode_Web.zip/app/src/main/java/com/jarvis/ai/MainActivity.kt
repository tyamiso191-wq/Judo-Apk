package com.jarvis.ai

import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.jarvis.ai.attach.AttachmentLoader
import com.jarvis.ai.reminders.ReminderStore
import com.jarvis.ai.theme.JarvisTheme
import com.jarvis.ai.ui.ApiKeyScreen
import com.jarvis.ai.ui.MainScreen
import com.jarvis.ai.ui.MemoryScreen
import com.jarvis.ai.ui.TerminalScreen
import com.jarvis.ai.vision.CameraVisionController
import com.jarvis.ai.vision.ScreenVisionController
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class MainActivity : ComponentActivity() {

    private val vm: JarvisViewModel by viewModels()

    // Ekran yönü tercihi (☰ menüsünden değiştirilir). İlk açılışta DİKEY.
    private val uiPrefs by lazy { getSharedPreferences("jarvis_ui", MODE_PRIVATE) }
    private var portrait by mutableStateOf(true)

    private fun applyOrientation() {
        requestedOrientation = if (portrait) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    private fun toggleOrientation() {
        portrait = !portrait
        uiPrefs.edit().putBoolean("portrait", portrait).apply()
        applyOrientation()
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            // Mic permission granted – user can toggle mic
        }
    }

    // Yerel müzik kütüphanesini okuma + (API 33+) bildirim izni. play_song
    // fonksiyonu her çağrıldığında kullanıcıya izin sormak Android'de mümkün
    // değil (arka planda, konuşma ortasında bir dialog açmak kötü bir deneyim
    // olurdu) — bu yüzden açılışta bir kez soruyoruz. Reddedilirse
    // MusicController otomatik olarak YouTube arama moduna düşüyor, uygulama
    // kırılmıyor.
    private val musicPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* sonuçla ilgilenmemize gerek yok; MusicController kendi kontrol ediyor */ }

    // Sohbet çubuğundaki 📎 menüsü: fotoğraf (sistem foto seçicisi, izin gerekmez)
    // ve herhangi bir dosya (sistem dosya seçicisi, izin gerekmez). Seçilenler
    // ViewModel'de "ek" olarak bekler, gönder tuşuna basılınca mesajla gider.
    private val photoPickerLauncher = registerForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(AttachmentLoader.MAX_IMAGES)
    ) { uris -> if (uris.isNotEmpty()) vm.addAttachments(uris) }

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> if (uris.isNotEmpty()) vm.addAttachments(uris) }

    // Sohbet çubuğundaki kamera düğmesi: doğrudan kamerayı açar, çekilen fotoğraf ek olarak eklenir.
    private var pendingCameraUri: android.net.Uri? = null

    private val takePictureLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { ok ->
        val uri = pendingCameraUri
        pendingCameraUri = null
        if (ok && uri != null) vm.addAttachments(listOf(uri))
    }

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) launchCamera()
        else android.widget.Toast.makeText(this, "Kamera izni verilmedi", android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun launchCamera() {
        try {
            val dir = java.io.File(cacheDir, "chat_attachments").apply { mkdirs() }
            val file = java.io.File(dir, "kamera_${System.currentTimeMillis()}.jpg")
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            pendingCameraUri = uri
            takePictureLauncher.launch(uri)
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "Kamera açılamadı", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun takePhoto() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            launchCamera()
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // analyze_screen için: ekran kaydı izni bir sistem Activity sonucu
    // olduğundan sohbet ortasında sessizce alınamıyor -- açılışta bir kez
    // istenir (bkz. requestScreenCapturePermission), sonucu
    // ScreenVisionController süreç canlı olduğu sürece saklar.
    private var pendingScreenPermission: CompletableDeferred<Boolean>? = null

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        ScreenVisionController.onPermissionResult(result.resultCode, result.data)
        pendingScreenPermission?.complete(ScreenVisionController.hasPermission)
        pendingScreenPermission = null
    }

    /** @return pencere açıldıysa true (açılamadıysa false). */
    private fun requestScreenCapturePermission(): Boolean {
        return try {
            screenCaptureLauncher.launch(ScreenVisionController.buildPermissionRequestIntent(this))
            true
        } catch (e: Exception) {
            // Bazı cihazlarda (ör. Android TV, MediaProjection desteklemeyen
            // özel ROM'lar) bu intent hiç açılamayabilir -- analyze_screen
            // o zaman sadece "izin yok" hatası döner, uygulama kırılmaz.
            false
        }
    }

    /**
     * Android 14+ ekran yakalama iznini tek kullanımlık yaptığı için analyze_screen her
     * seferinde izni yeniden ister: sistem penceresi açılır, kullanıcı onaylayınca devam edilir.
     */
    private suspend fun askScreenPermission(): Boolean {
        val deferred = CompletableDeferred<Boolean>()
        pendingScreenPermission = deferred
        val launched = withContext(Dispatchers.Main) { requestScreenCapturePermission() }
        if (!launched) {
            pendingScreenPermission = null
            return false
        }
        val granted = withTimeoutOrNull(30_000L) { deferred.await() } ?: false
        pendingScreenPermission = null
        return granted
    }

    private fun requestMusicPermissionsIfNeeded() {
        val perms = mutableListOf<String>()
        perms += if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms += Manifest.permission.POST_NOTIFICATIONS
        }
        // Takvim araçları (get/add/delete_calendar_event) için: açılışta bir
        // kez sorulur, reddedilirse fonksiyonlar çağrıldığında Judo
        // kullanıcıya izni açmasını nazikçe söyler, uygulama kırılmaz.
        perms += Manifest.permission.READ_CALENDAR
        perms += Manifest.permission.WRITE_CALENDAR
        // analyze_webcam için: aynı şekilde açılışta bir kez sorulur.
        perms += Manifest.permission.CAMERA
        // "Judo" uyandırma kelimesi (arka plan dinleme) için de mikrofon
        // izni gerekiyor -- açılışta bir kez sorulur, kullanıcı özelliği
        // sonradan 🎙 simgesinden açabilir.
        perms += Manifest.permission.RECORD_AUDIO
        val notGranted = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (notGranted.isNotEmpty()) {
            musicPermissionLauncher.launch(notGranted.toTypedArray())
        }
        // Telefon yeniden başlatılınca kaybolan alarmları (varsa) yeniden kur.
        ReminderStore.rescheduleAll(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        portrait = true
        applyOrientation()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        enableImmersiveMode()
        requestMusicPermissionsIfNeeded()
        // Android 13 ve altında izin bir kez alınıp yeniden kullanılabilir; 14+'ta tek
        // kullanımlık olduğu için açılışta boşa harcanmaz, analyze_screen anında istenir.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            requestScreenCapturePermission()
        }
        ScreenVisionController.permissionRequester = { askScreenPermission() }

        // analyze_webcam / analyze_screen fonksiyonları Activity/UI erişimi
        // gerektirdiği için gerçek yakalayıcılar burada, ViewModel'e bağlanır.
        vm.cameraCaptureProvider = { CameraVisionController.captureJpeg(this) }
        vm.screenCaptureProvider = { ScreenVisionController.captureJpeg(this) }

        setContent {
            JarvisTheme {
                val needsKey by vm.needsKey.collectAsState()
                val orbState by vm.orbState.collectAsState()
                val status by vm.status.collectAsState()
                val logs by vm.logs.collectAsState()
                val micOn by vm.micOn.collectAsState()
                val level by vm.audioLevel.collectAsState()
                val apiKey by vm.apiKey.collectAsState()
                val isConnected by vm.isConnected.collectAsState()
                val weather by vm.weather.collectAsState()
                val speedLabel by vm.speedLabel.collectAsState()
                val voiceLabel by vm.voiceLabel.collectAsState()
                val showTerminal by vm.showTerminal.collectAsState()
                val terminalHistory by vm.terminalHistory.collectAsState()
                val attachments by vm.attachments.collectAsState()
                val wakeWordEnabled by vm.wakeWordEnabled.collectAsState()
                val memoryCount by vm.memoryCount.collectAsState()
                val showMemory by vm.showMemory.collectAsState()
                val showStudy by vm.showStudy.collectAsState()
                val showCode by vm.showCode.collectAsState()
                val codeEvents by vm.codeEvents.collectAsState()
                val codeBusy by vm.codeBusy.collectAsState()
                val studyProfile by vm.studyProfile.collectAsState()
                val keyCheck by vm.keyCheck.collectAsState()
                val muted by vm.muted.collectAsState()
                val sessions by vm.sessions.collectAsState()
                val currentTitle by vm.currentTitle.collectAsState()

                LaunchedEffect(apiKey) {
                    if (!apiKey.isNullOrBlank()) {
                        vm.connect(apiKey!!)
                    }
                }

                if (needsKey) {
                    ApiKeyScreen(
                        onSave = { key -> vm.saveApiKey(key) },
                        checkState = keyCheck
                    )
                } else if (showTerminal) {
                    TerminalScreen(
                        history = terminalHistory,
                        onRunCommand = { vm.runTerminalCommand(it) },
                        onClose = { vm.toggleTerminal() }
                    )
                } else if (showCode) {
                    com.jarvis.ai.ui.JudoCodeScreen(
                        events = codeEvents,
                        busy = codeBusy,
                        onSend = { vm.sendCodeMessage(it) },
                        onStop = { vm.stopCode() },
                        onClear = { vm.clearCode() },
                        onSaveFile = { vm.saveCodeFile(it) },
                        onClose = { vm.toggleCodeScreen() }
                    )
                } else if (showStudy) {
                    com.jarvis.ai.ui.StudyScreen(
                        profile = studyProfile,
                        attachmentCount = attachments.size,
                        onPickPhoto = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onTakePhoto = { takePhoto() },
                        onStart = { vm.startStudy(it) },
                        onContinue = { vm.continueStudy() },
                        onEnd = { vm.endStudy() },
                        onClose = { vm.toggleStudyScreen() }
                    )
                } else if (showMemory) {
                    MemoryScreen(
                        items = com.jarvis.ai.memory.MemoryStore.list(this@MainActivity),
                        onDelete = { vm.deleteMemoryItem(it) },
                        onClose = { vm.toggleMemoryScreen() }
                    )
                } else {
                    MainScreen(
                        orbState = orbState,
                        status = status,
                        logs = logs,
                        micOn = micOn,
                        isConnected = isConnected,
                        audioLevel = level,
                        weather = weather,
                        speedLabel = speedLabel,
                        onCycleSpeed = { vm.cycleSpeed() },
                        voiceLabel = voiceLabel,
                        onCycleVoice = { vm.cycleVoice() },
                        onToggleMic = {
                            ensureMicPermission {
                                vm.toggleMic()
                            }
                        },
                        onStart = { vm.connect() },
                        onStop = { vm.cancelReply() },
                        onSendText = { vm.sendText(it) },
                        attachments = attachments,
                        onPickPhoto = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onPickFile = { filePickerLauncher.launch(arrayOf("*/*")) },
                        onTakePhoto = { takePhoto() },
                        onRemoveAttachment = { vm.removeAttachment(it) },
                        onChangeKey = { vm.clearApiKey() },
                        onOpenTerminal = { vm.toggleTerminal() },
                        onOpenStudy = { vm.toggleStudyScreen() },
                        onOpenCode = { vm.toggleCodeScreen() },
                        onSaveAttachment = { vm.saveAttachmentToDevice(it) },
                        wakeWordEnabled = wakeWordEnabled,
                        onToggleWakeWord = { vm.toggleWakeWord() },
                        memoryCount = memoryCount,
                        onOpenMemory = { vm.toggleMemoryScreen() },
                        portrait = portrait,
                        onToggleOrientation = { toggleOrientation() },
                        muted = muted,
                        onToggleMute = { vm.toggleMute() },
                        sessions = sessions,
                        currentTitle = currentTitle,
                        onNewChat = { vm.newChat() },
                        onOpenSession = { vm.openSession(it) },
                        onDeleteSession = { vm.deleteSession(it) }
                    )
                }
            }
        }
    }

    private fun ensureMicPermission(onGranted: () -> Unit) {
        when {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED -> onGranted()
            else -> permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    /**
     * Sistem çubuklarını (nav bar + status bar) gizler. Oyunlardaki gibi:
     * kenardan içeri kaydırınca geçici olarak görünür, sonra kendiliğinden
     * tekrar gizlenir. Kullanıcı ekranın yanındaki geri/ana ekran tuşlarını
     * sürekli görmek istemiyordu.
     */
    private fun enableImmersiveMode() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onStart() {
        super.onStart()
        ScreenVisionController.appVisible = true
        com.jarvis.ai.voice.BeepSuppressor.restoreIfLeftover(applicationContext)
    }

    override fun onStop() {
        ScreenVisionController.appVisible = false
        super.onStop()
    }

    override fun onDestroy() {
        if (isFinishing) ScreenVisionController.permissionRequester = null
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Sistem çubukları başka bir pencere/dialog vs. yüzünden tekrar açığa
        // çıkarsa (odak geri geldiğinde), immersive modu yeniden uygula.
        if (hasFocus) enableImmersiveMode()
    }
}
