package com.jarvis.ai.code

import android.content.Context
import com.jarvis.ai.agents.AiRuntime
import com.jarvis.ai.agents.CallContext
import com.jarvis.ai.agents.ErrorKind
import com.jarvis.ai.agents.GeminiClient
import com.jarvis.ai.agents.LlmException
import com.jarvis.ai.files.FileTool
import com.jarvis.ai.terminal.TerminalRunner
import com.jarvis.ai.web.WebSearchClient
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

enum class CodeEventKind { USER, ASSISTANT, TOOL, ERROR }

data class CodeEvent(
    val kind: CodeEventKind,
    val text: String,
    val detail: String? = null,
    /** send_file ile kullanıcıya gönderilen dosya (ekranda KAYDET düğmesi çıkar). */
    val file: com.jarvis.ai.files.FileTool.StagedFile? = null
)

/**
 * Judo Code: Claude Code tarzı ajan modu. Model, çalışma klasöründe (terminal ile ortak
 * sandbox: filesDir/terminal_workspace) dosya listeler / okur / yazar / düzenler ve kabuk
 * komutu çalıştırır; sonucu görüp tekrar karar verir (araç döngüsü), iş bitince özet yazar.
 *
 * SINIRLAMA: Telefonda gradle/JDK/derleyici yoktur; komutlar cihazın /system/bin/sh kabuğunda
 * ve sandbox içinde çalışır.
 */
class JudoCodeAgent(private val appContext: Context) {
    private val runtime = AiRuntime.get(appContext)
    @Volatile private var preferredModelIdx = 0

    companion object {
        private const val MAX_TURNS = 25
        private const val TOTAL_TIMEOUT_MS = 300_000L
        private const val MAX_HISTORY = 20
        private const val MAX_READ_CHARS = 16_000

        private const val SYSTEM = """Sen Judo Code'sun: telefonun içinde çalışan bir kodlama ajanısın (Claude Code gibi).
Kullanıcının isteğini çalışma klasöründeki dosyaları araçlarla inceleyip değiştirerek GERÇEKTEN yaparsın.
Kurallar:
- Önce list_files / read_file ile mevcut durumu anla, tahmin yürütme.
- Küçük değişiklikler için edit_file, yeni dosya veya tam yeniden yazım için write_file kullan.
- İnternetten bilgi gerekiyorsa web_search ile ara, read_webpage ile sayfayı oku; kaynağı belirt. Güncel/bilmediğin şeyleri tahmin etme, ara.
- Kullanıcı bir dosya (PDF, görsel, zip, kod vb.) isterse web_search ile bul, download_file ile çalışma klasörüne indir, send_file ile kullanıcıya gönder.
- Üretilen dosyaları da (zip, rapor vb.) send_file ile kullanıcıya verebilirsin.
- Değişiklikten sonra mümkünse run_command ile doğrula (cat, grep, sh script.sh, python varsa python vb.).
- Bu ortamda gradle/JDK/derleyici yok; yalnızca cihazdaki sh ve kurulu araçlar çalışır. Çalışmayan şeyi çalıştı deme.
- Yolları çalışma klasörüne göre göreli yaz. Klasör dışına çıkma.
- Bitirince Türkçe, kısa ve net özet ver: ne yaptın, hangi dosyalar değişti, nasıl çalıştırılır.
Kullanıcıya "sen" diye, samimi ve kısa konuş."""
    }

    private fun root(): File = TerminalRunner.workspaceDir(appContext.filesDir)

    /** Yolu çalışma klasörünün içine hapseder; dışarı çıkıyorsa null. */
    private fun resolve(path: String): File? {
        val base = root().canonicalFile
        val f = File(base, path.trim().trimStart('/')).canonicalFile
        return if (f == base || f.path.startsWith(base.path + File.separator)) f else null
    }

    private fun tool(name: String, desc: String, props: JSONObject, required: List<String>): JSONObject =
        JSONObject().put("type", "function").put(
            "function", JSONObject()
                .put("name", name)
                .put("description", desc)
                .put(
                    "parameters", JSONObject()
                        .put("type", "object")
                        .put("properties", props)
                        .put("required", JSONArray(required))
                )
        )

    private fun str(desc: String) = JSONObject().put("type", "string").put("description", desc)

    private fun tools(): JSONArray = JSONArray()
        .put(tool("list_files", "Klasördeki dosyaları listeler (alt klasörler dahil, en fazla 200 satır).",
            JSONObject().put("path", str("Klasör yolu, boşsa kök")), emptyList()))
        .put(tool("read_file", "Metin dosyasını satır numaralarıyla okur.",
            JSONObject().put("path", str("Dosya yolu")), listOf("path")))
        .put(tool("write_file", "Dosyayı oluşturur veya tamamen üzerine yazar (klasörleri otomatik açar).",
            JSONObject().put("path", str("Dosya yolu")).put("content", str("Dosyanın tam içeriği")),
            listOf("path", "content")))
        .put(tool("edit_file", "Dosyada old_str metnini (tam olarak 1 kez geçmeli) new_str ile değiştirir.",
            JSONObject().put("path", str("Dosya yolu")).put("old_str", str("Değişecek metin"))
                .put("new_str", str("Yeni metin")), listOf("path", "old_str", "new_str")))
        .put(tool("web_search", "İnternette arama yapar (başlık, adres, özet döner). Güncel bilgi ve dosya/indirme bağlantısı bulmak için.",
            JSONObject().put("query", str("Arama sorgusu")).put("news", JSONObject().put("type", "boolean").put("description", "Haber araması mı")),
            listOf("query")))
        .put(tool("read_webpage", "Bir web sayfasının metnini okur (en fazla ~8000 karakter).",
            JSONObject().put("url", str("http/https adresi")), listOf("url")))
        .put(tool("download_file", "İnternetten bir dosyayı çalışma klasörüne indirir (25 MB sınır).",
            JSONObject().put("url", str("Dosya adresi")).put("path", str("Kaydedilecek yol, örn. indirilenler/rapor.pdf")),
            listOf("url", "path")))
        .put(tool("send_file", "Çalışma klasöründeki bir dosyayı kullanıcıya gönderir (kullanıcı telefona kaydedebilir).",
            JSONObject().put("path", str("Dosya yolu")), listOf("path")))
        .put(tool("run_command", "Çalışma klasöründe sh komutu çalıştırır (30 sn sınır, çıktı kırpılır).",
            JSONObject().put("command", str("Kabuk komutu")), listOf("command")))

    private suspend fun execute(name: String, args: JSONObject, onEvent: (CodeEvent) -> Unit): String = withContext(Dispatchers.IO) {
        try {
            when (name) {
                "list_files" -> {
                    val dir = resolve(args.optString("path", "")) ?: return@withContext "HATA: klasör dışına çıkılamaz."
                    if (!dir.isDirectory) return@withContext "HATA: klasör yok."
                    val base = root().canonicalFile
                    val lines = dir.walkTopDown().filter { it != dir }.take(200).map {
                        val rel = it.relativeTo(base).path
                        if (it.isDirectory) "$rel/" else "$rel (${it.length()} B)"
                    }.toList()
                    if (lines.isEmpty()) "(boş)" else lines.joinToString("\n")
                }
                "read_file" -> {
                    val f = resolve(args.optString("path")) ?: return@withContext "HATA: klasör dışına çıkılamaz."
                    if (!f.isFile) return@withContext "HATA: dosya yok."
                    val text = f.readText()
                    val numbered = text.lines().mapIndexed { i, l -> "${i + 1}\t$l" }.joinToString("\n")
                    if (numbered.length > MAX_READ_CHARS) numbered.take(MAX_READ_CHARS) + "\n…(kırpıldı)" else numbered
                }
                "write_file" -> {
                    val f = resolve(args.optString("path")) ?: return@withContext "HATA: klasör dışına çıkılamaz."
                    if (f == root().canonicalFile) return@withContext "HATA: geçersiz yol."
                    f.parentFile?.mkdirs()
                    val content = args.optString("content")
                    f.writeText(content)
                    "Yazıldı: ${args.optString("path")} (${content.length} karakter)"
                }
                "edit_file" -> {
                    val f = resolve(args.optString("path")) ?: return@withContext "HATA: klasör dışına çıkılamaz."
                    if (!f.isFile) return@withContext "HATA: dosya yok."
                    val old = args.optString("old_str")
                    if (old.isEmpty()) return@withContext "HATA: old_str boş."
                    val text = f.readText()
                    var count = 0
                    var from = text.indexOf(old)
                    while (from >= 0) { count++; from = text.indexOf(old, from + old.length) }
                    when {
                        count == 0 -> "HATA: old_str dosyada bulunamadı (boşluk/girinti birebir aynı olmalı)."
                        count > 1 -> "HATA: old_str $count kez geçiyor; daha fazla bağlam ekle."
                        else -> { f.writeText(text.replace(old, args.optString("new_str"))); "Düzenlendi: ${args.optString("path")}" }
                    }
                }
                "web_search" -> WebSearchClient.search(args.optString("query"), args.optBoolean("news", false)).toString()
                "read_webpage" -> WebSearchClient.readPage(args.optString("url"), 8000).toString()
                "download_file" -> {
                    val f = resolve(args.optString("path")) ?: return@withContext "HATA: klasör dışına çıkılamaz."
                    if (f == root().canonicalFile || f.isDirectory) return@withContext "HATA: geçersiz yol."
                    WebSearchClient.download(args.optString("url"), f).put("path", args.optString("path")).toString()
                }
                "send_file" -> {
                    val f = resolve(args.optString("path")) ?: return@withContext "HATA: klasör dışına çıkılamaz."
                    if (!f.isFile) return@withContext "HATA: dosya yok."
                    if (f.length() > 20L * 1024 * 1024) return@withContext "HATA: dosya 20 MB'tan büyük."
                    val staged = FileTool.stageFile(appContext, f.name, f.readBytes())
                    onEvent(CodeEvent(CodeEventKind.TOOL, "Dosya gönderildi: ${f.name}", null, staged))
                    "Dosya kullanıcıya gönderildi: ${f.name}"
                }
                "run_command" -> {
                    val r = TerminalRunner.run(appContext.filesDir, args.optString("command"), 30_000L)
                    r.output + "\n[çıkış kodu: ${r.exitCode}${if (r.timedOut) ", zaman aşımı" else ""}]"
                }
                else -> "HATA: bilinmeyen araç $name"
            }
        } catch (e: Exception) {
            "HATA: ${e.message}"
        }
    }

    private fun summarize(name: String, args: JSONObject): String = when (name) {
        "run_command" -> "$ ${args.optString("command")}"
        "web_search" -> "🔎 ${args.optString("query")}"
        "read_webpage", "download_file" -> "🌐 $name ${args.optString("url")}"
        else -> "$name ${args.optString("path")}".trim()
    }

    /** history: ("user"/"model", metin) çiftleri; son eleman kullanıcının yeni isteği. */
    suspend fun run(
        history: List<Pair<String, String>>,
        onEvent: (CodeEvent) -> Unit
    ): Result<String> = withContext(Dispatchers.IO) {
        val result = withTimeoutOrNull(TOTAL_TIMEOUT_MS) {
            var idx = preferredModelIdx
            var last: Result<String> = Result.failure(IOException("Cevap alınamadı."))
            while (idx < GeminiClient.CHAT_MODELS.size) {
                try {
                    val text = loop(idx, history.takeLast(MAX_HISTORY), onEvent)
                    preferredModelIdx = idx
                    return@withTimeoutOrNull Result.success(text)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: LlmException) {
                    val skip = e.kind == ErrorKind.MODEL_UNAVAILABLE || e.kind == ErrorKind.MODEL_INCOMPATIBLE ||
                        e.kind == ErrorKind.TRANSIENT_SERVER || e.kind == ErrorKind.EMPTY_RESPONSE ||
                        e.kind == ErrorKind.RATE_LIMIT_MODEL || e.kind == ErrorKind.RATE_LIMIT_ACCOUNT
                    last = Result.failure(IOException("Model hatası: ${e.message}"))
                    if (!skip) break
                    idx++
                } catch (e: Exception) {
                    last = Result.failure(e)
                    break
                }
            }
            last
        }
        result ?: Result.failure(IOException("Judo Code 5 dakikada bitiremedi. İsteği küçült ve tekrar dene."))
    }

    private suspend fun loop(modelIdx: Int, history: List<Pair<String, String>>, onEvent: (CodeEvent) -> Unit): String {
        val model = GeminiClient.CHAT_MODELS[modelIdx]
        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", SYSTEM))
        history.forEach { (r, t) ->
            messages.put(JSONObject().put("role", if (r == "model") "assistant" else "user").put("content", t))
        }
        val taskId = "code-${System.currentTimeMillis()}"
        var lastText = ""
        for (turn in 0 until MAX_TURNS) {
            val lastTurn = turn == MAX_TURNS - 1
            val body = JSONObject()
                .put("messages", messages)
                .put("max_tokens", minOf(4096, model.maxCompletion ?: 4096))
                .put("temperature", 0.3)
                .put("tools", tools())
                .put("tool_choice", if (lastTurn) "none" else "auto")
                .put("reasoning_effort", "low")
            val reply = runtime.geminiCaller.complete(CallContext(taskId, "JUDO#code", "kodlama"), model, body)
            val message = reply.message
            val text = when (val c = message.opt("content")) {
                is String -> c
                is JSONArray -> (0 until c.length()).joinToString("") { c.optJSONObject(it)?.optString("text").orEmpty() }
                else -> ""
            }
            val calls = message.optJSONArray("tool_calls")
            if (calls == null || calls.length() == 0) {
                if (text.isBlank()) throw LlmException(ErrorKind.EMPTY_RESPONSE, null, null, "Boş yanıt döndü.", model.id)
                return text.trim()
            }
            if (text.isNotBlank()) onEvent(CodeEvent(CodeEventKind.ASSISTANT, text.trim()))
            messages.put(JSONObject().put("role", "assistant").put("content", text).put("tool_calls", calls))
            for (i in 0 until calls.length()) {
                val call = calls.optJSONObject(i) ?: continue
                val fn = call.optJSONObject("function") ?: continue
                val name = fn.optString("name")
                val args = try { JSONObject(fn.optString("arguments", "{}")) } catch (e: Exception) { JSONObject() }
                val out = execute(name, args, onEvent)
                onEvent(CodeEvent(CodeEventKind.TOOL, summarize(name, args), out.take(600)))
                messages.put(
                    JSONObject().put("role", "tool").put("name", name)
                        .put("tool_call_id", call.optString("id")).put("content", out)
                )
            }
            lastText = text
        }
        return lastText.ifBlank { "Tur sınırına ulaştım; yaptıklarım yukarıda. Devam etmemi istersen yaz." }
    }
}
