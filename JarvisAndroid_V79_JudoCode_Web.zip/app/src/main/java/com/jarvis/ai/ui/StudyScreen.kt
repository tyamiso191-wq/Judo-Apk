package com.jarvis.ai.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.study.StudyProfile
import com.jarvis.ai.theme.*
import java.time.LocalDate
import java.time.temporal.ChronoUnit

private val GRADES = listOf("5. sınıf", "6. sınıf", "7. sınıf", "8. sınıf", "9. sınıf", "10. sınıf", "11. sınıf", "12. sınıf", "Mezun")
private val SUBJECTS = listOf("Matematik", "Fizik", "Kimya", "Biyoloji", "Türkçe", "Edebiyat", "Tarih", "Coğrafya", "İngilizce", "Fen Bilimleri", "Sosyal Bilgiler")
private val EXAMS = listOf("1. dönem 1. yazılı", "1. dönem 2. yazılı", "2. dönem 1. yazılı", "2. dönem 2. yazılı")

/** Ders çalışma: bilgileri toplar, Judo araştırıp plan çıkarır ve konuları tek tek anlatır. */
@Composable
fun StudyScreen(
    profile: StudyProfile?,
    attachmentCount: Int,
    onPickPhoto: () -> Unit,
    onTakePhoto: () -> Unit,
    onStart: (StudyProfile) -> Unit,
    onContinue: () -> Unit,
    onEnd: () -> Unit,
    onClose: () -> Unit
) {
    var editing by rememberSaveable { mutableStateOf(profile == null) }
    BackHandler(onBack = onClose)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgTop, Bg)))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 10.dp, bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Ders çalışma", color = Text, fontSize = 22.sp, fontWeight = FontWeight.Medium, fontFamily = UiFont)
            Box(
                modifier = Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClose),
                contentAlignment = Alignment.Center
            ) { JIcon(JI.Close, tint = Dim, size = 22.dp) }
        }

        if (!editing && profile != null) {
            StudySummary(profile, onContinue, onNew = { editing = true }, onEnd = onEnd)
        } else {
            StudyForm(attachmentCount, onPickPhoto, onTakePhoto, onStart)
        }
    }
}

@Composable
private fun StudySummary(
    p: StudyProfile,
    onContinue: () -> Unit,
    onNew: () -> Unit,
    onEnd: () -> Unit
) {
    val today = LocalDate.now()
    val left = runCatching { ChronoUnit.DAYS.between(today, LocalDate.parse(p.deadline)) }.getOrDefault(0L).coerceAtLeast(0)
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White.copy(alpha = 0.07f))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("${p.grade} · ${p.subject}", color = Text, fontSize = 18.sp, fontWeight = FontWeight.Medium, fontFamily = UiFont)
            Text("Amaç: ${p.mode}   ·   Hedef: ${p.targetScore.ifBlank { "-" }}", color = Dim, fontSize = 14.sp, fontFamily = UiFont)
            Text("$left gün kaldı (bitiş ${p.deadline})", color = Dim, fontSize = 14.sp, fontFamily = UiFont)
            Text("Anlatım: ${if (p.voice) "Sesli" else "Metin"}", color = Dim, fontSize = 14.sp, fontFamily = UiFont)
            Text(
                "Tamamlanan konu: ${p.doneTopics.size}" + if (p.plan.isBlank()) "   ·   plan henüz yok" else "   ·   plan hazır",
                color = Teal, fontSize = 14.sp, fontFamily = UiFont
            )
        }
        BigButton("Çalışmaya devam et", true, onClick = onContinue)
        BigButton("Yeni plan oluştur", false, onClick = onNew)
        Text(
            "Planı sil",
            color = Dim, fontSize = 14.sp, fontFamily = UiFont,
            modifier = Modifier.align(Alignment.CenterHorizontally).clip(RoundedCornerShape(10.dp)).clickable(onClick = onEnd).padding(12.dp)
        )
    }
}

@Composable
private fun StudyForm(
    attachmentCount: Int,
    onPickPhoto: () -> Unit,
    onTakePhoto: () -> Unit,
    onStart: (StudyProfile) -> Unit
) {
    var grade by rememberSaveable { mutableStateOf("") }
    var mode by rememberSaveable { mutableStateOf("Sınav") }
    var subject by rememberSaveable { mutableStateOf("") }
    var daysText by rememberSaveable { mutableStateOf("") }
    var target by rememberSaveable { mutableStateOf("") }
    var hasTopics by rememberSaveable { mutableStateOf("") } // "evet" | "hayir" | ""
    var topics by rememberSaveable { mutableStateOf("") }
    var exam by rememberSaveable { mutableStateOf("") }
    var voice by rememberSaveable { mutableStateOf("") }     // "sesli" | "metin" | ""

    val days = daysText.toIntOrNull() ?: 0
    val topicsOk = when (hasTopics) {
        "evet" -> topics.isNotBlank() || attachmentCount > 0
        "hayir" -> exam.isNotBlank()
        else -> false
    }
    val ready = grade.isNotBlank() && subject.isNotBlank() && days > 0 && topicsOk && voice.isNotBlank()

    Column(
        modifier = Modifier.fillMaxSize(),
    ) {
        Column(
            modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Label("Kaçıncı sınıfsın?")
            ChipRow(GRADES, grade) { grade = it }

            Label("Ne için çalışıyorsun?")
            ChipRow(listOf("Tekrar", "Sınav"), mode) { mode = it }

            Label("Hangi ders?")
            Field(subject, { subject = it }, "Örn. Matematik")
            ChipRow(SUBJECTS, subject) { subject = it }

            Label("Kaç günün var?")
            Field(daysText, { daysText = it.filter { c -> c.isDigit() }.take(3) }, "Gün sayısı", numeric = true)
            ChipRow(listOf("3", "7", "14", "30"), daysText) { daysText = it }

            Label("Hedef puanın?")
            Field(target, { target = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.take(6) }, "Örn. 85", numeric = true)

            Label("Hocan sana neleri çalışacağını söyledi mi?")
            ChipRow(listOf("Evet", "Hayır"), when (hasTopics) { "evet" -> "Evet"; "hayir" -> "Hayır"; else -> "" }) {
                hasTopics = if (it == "Evet") "evet" else "hayir"
            }
            if (hasTopics == "evet") {
                Field(topics, { topics = it }, "Konuları yaz ya da fotoğrafını ekle", minLines = 3)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallButton("Fotoğraf ekle", onPickPhoto)
                    SmallButton("Kamera", onTakePhoto)
                }
                if (attachmentCount > 0) {
                    Text("$attachmentCount ek eklendi", color = Green, fontSize = 13.sp, fontFamily = UiFont)
                }
            } else if (hasTopics == "hayir") {
                Label("Hangi yazılıya hazırlanıyorsun?")
                ChipRow(EXAMS, exam) { exam = it }
            }

            Label("Konuları nasıl anlatayım?")
            ChipRow(listOf("Sesli", "Metin"), when (voice) { "sesli" -> "Sesli"; "metin" -> "Metin"; else -> "" }) {
                voice = if (it == "Sesli") "sesli" else "metin"
            }
            Spacer(Modifier.height(8.dp))
        }

        Box(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp)) {
            BigButton("Başla", primary = true, enabled = ready) {
                val d = days.coerceIn(1, 365)
                val today = LocalDate.now()
                onStart(
                    StudyProfile(
                        grade = grade,
                        subject = subject.trim(),
                        mode = mode,
                        days = d,
                        startDate = today.toString(),
                        deadline = today.plusDays(d.toLong()).toString(),
                        targetScore = target.trim(),
                        teacherTopics = if (hasTopics == "evet") topics.trim() else "",
                        hasTeacherPhoto = hasTopics == "evet" && attachmentCount > 0,
                        writtenExam = if (hasTopics == "hayir") exam else "",
                        voice = voice == "sesli",
                        active = true
                    )
                )
            }
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(text, color = Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, fontFamily = UiFont, modifier = Modifier.padding(top = 10.dp))
}

@Composable
private fun ChipRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { o ->
            val sel = o == selected
            Text(
                o,
                color = if (sel) Bg else Text,
                fontSize = 14.sp,
                fontFamily = UiFont,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (sel) Teal else Color.White.copy(alpha = 0.08f))
                    .clickable { onSelect(o) }
                    .padding(horizontal = 14.dp, vertical = 9.dp)
            )
        }
    }
}

@Composable
private fun Field(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    numeric: Boolean = false,
    minLines: Int = 1
) {
    BasicTextField(
        value = value,
        onValueChange = onChange,
        singleLine = minLines == 1,
        minLines = minLines,
        maxLines = if (minLines == 1) 1 else 8,
        textStyle = TextStyle(color = Text, fontSize = 16.sp, fontFamily = UiFont),
        cursorBrush = SolidColor(Teal),
        keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        decorationBox = { inner ->
            Box {
                if (value.isEmpty()) Text(hint, color = Dim, fontSize = 16.sp, fontFamily = UiFont)
                inner()
            }
        }
    )
}

@Composable
private fun SmallButton(text: String, onClick: () -> Unit) {
    Text(
        text,
        color = Text,
        fontSize = 14.sp,
        fontFamily = UiFont,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp)
    )
}

@Composable
private fun BigButton(text: String, primary: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(50))
            .background((if (primary) Teal else Color.White.copy(alpha = 0.08f)).copy(alpha = if (enabled) 1f else 0.35f))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 15.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (primary) Bg else Text, fontSize = 16.sp, fontWeight = FontWeight.Medium, fontFamily = UiFont)
    }
}
