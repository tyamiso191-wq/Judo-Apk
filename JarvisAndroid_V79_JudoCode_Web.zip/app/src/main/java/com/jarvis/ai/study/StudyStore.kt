package com.jarvis.ai.study

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** Ders çalışma planının girdileri ve ilerlemesi (telefonda saklanır). */
data class StudyProfile(
    val grade: String,
    val subject: String,
    val mode: String,            // "Tekrar" | "Sınav"
    val days: Int,
    val startDate: String,       // ISO: 2026-11-03
    val deadline: String,        // ISO
    val targetScore: String,
    val teacherTopics: String,   // öğretmen konu söylediyse yazılan metin
    val hasTeacherPhoto: Boolean,
    val writtenExam: String,     // öğretmen konu söylemediyse: "1. dönem 1. yazılı" vb.
    val voice: Boolean,          // true: sesli, false: metin
    val active: Boolean = false, // şu anki sohbet ders modunda mı
    val plan: String = "",
    val doneTopics: List<String> = emptyList(),
    val lastDayClosed: String = ""
)

object StudyStore {
    private const val PREFS = "study_profile"
    private const val KEY = "profile"

    fun load(ctx: Context): StudyProfile? {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return null
        return try {
            val o = JSONObject(raw)
            val arr = o.optJSONArray("done") ?: JSONArray()
            StudyProfile(
                grade = o.optString("grade"),
                subject = o.optString("subject"),
                mode = o.optString("mode"),
                days = o.optInt("days", 7),
                startDate = o.optString("start"),
                deadline = o.optString("deadline"),
                targetScore = o.optString("target"),
                teacherTopics = o.optString("topics"),
                hasTeacherPhoto = o.optBoolean("photo"),
                writtenExam = o.optString("exam"),
                voice = o.optBoolean("voice"),
                active = o.optBoolean("active"),
                plan = o.optString("plan"),
                doneTopics = (0 until arr.length()).map { arr.getString(it) },
                lastDayClosed = o.optString("closed")
            )
        } catch (_: Exception) {
            null
        }
    }

    fun save(ctx: Context, p: StudyProfile) {
        val o = JSONObject()
            .put("grade", p.grade).put("subject", p.subject).put("mode", p.mode)
            .put("days", p.days).put("start", p.startDate).put("deadline", p.deadline)
            .put("target", p.targetScore).put("topics", p.teacherTopics)
            .put("photo", p.hasTeacherPhoto).put("exam", p.writtenExam)
            .put("voice", p.voice).put("active", p.active).put("plan", p.plan)
            .put("done", JSONArray(p.doneTopics)).put("closed", p.lastDayClosed)
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}

/** Ders modundayken modele her mesajda eklenen yönerge + öğrenci bilgisi. */
object StudyPrompt {
    fun build(p: StudyProfile, today: LocalDate = LocalDate.now()): String {
        val start = runCatching { LocalDate.parse(p.startDate) }.getOrDefault(today)
        val end = runCatching { LocalDate.parse(p.deadline) }.getOrDefault(today.plusDays(p.days.toLong()))
        val daysLeft = ChronoUnit.DAYS.between(today, end).coerceAtLeast(0)
        val dayNo = (ChronoUnit.DAYS.between(start, today) + 1).coerceAtLeast(1)
        val scope = if (p.teacherTopics.isNotBlank() || p.hasTeacherPhoto) {
            "Öğretmenin söylediği konular: " +
                (p.teacherTopics.ifBlank { "(metin yok)" }) +
                (if (p.hasTeacherPhoto) " (ayrıca öğretmenin konu listesinin fotoğrafı gönderildi; onu oku)" else "")
        } else {
            "Öğretmen konu söylemedi; kapsam: MEB müfredatına göre ${p.writtenExam.ifBlank { "dönem yazılısı" }}."
        }
        val closedToday = p.lastDayClosed == today.toString()
        return buildString {
            appendLine("=== DERS ÇALIŞMA MODU (AKTİF) ===")
            appendLine("Öğrenci: ${p.grade}, ders: ${p.subject}, amaç: ${p.mode}.")
            appendLine("Süre: ${p.days} gün (bitiş ${p.deadline}). Bugün ${today} = $dayNo. gün, $daysLeft gün kaldı.")
            appendLine("Hedef puan: ${p.targetScore.ifBlank { "belirtilmedi" }}.")
            appendLine(scope)
            appendLine(
                if (p.voice) "Anlatım: SESLİ. Cevaplar sesli okunacak: kısa cümleler yaz, tablo/sembol/madde işareti/emoji kullanma."
                else "Anlatım: METİN. Gerekirse kısa listeler ve örnekler kullanabilirsin."
            )
            appendLine("Tamamlanan konular: ${if (p.doneTopics.isEmpty()) "henüz yok" else p.doneTopics.joinToString(", ")}")
            appendLine("Kayıtlı plan: ${if (p.plan.isBlank()) "henüz yok" else "\n" + p.plan}")
            if (closedToday) appendLine("BUGÜNKÜ ÇALIŞMA TAMAMLANDI: yeni konu anlatma; öğrenciye yarın devam edeceğinizi kısaca hatırlat, sorusu varsa cevapla.")
            if (daysLeft == 0L) appendLine("SÜRE DOLDU/SON GÜN: yeni konu yerine genel tekrar ve deneme çöz.")
            appendLine()
            appendLine("ÇALIŞMA AKIŞI (sırayla, adım atlamadan):")
            appendLine("1) PLAN YOKSA: önce web_search ile araştır (en az 2 arama, gerekirse read_webpage): MEB'in ${p.grade} ${p.subject} dersi kazanımları, yazılı/ortak sınav senaryoları ve örnek soruları. Sonra tek mesajda şunu söyle: kaç gün var, kaç konu çıktı, günde kaç saat çalışılmalı ve hangi gün hangi konular işlenecek. Planı <ders_plani>...</ders_plani> etiketi içine kısa ve gün gün yaz (etiket kullanıcıya gösterilmez); etiket dışında okunur bir özet ver. Planı verdikten sonra aynı mesajda 1. konunun anlatımına başla.")
            appendLine("2) KONU ANLATIMI: Her mesajda TEK konu. Önce konunun adı, sonra sade anlatım, 1-2 örnek, sınavda sık yapılan hata/püf nokta. Sonunda: \"Anlamadığın yer varsa yaz, yoksa 'test' yaz.\" de.")
            appendLine("3) KONU TESTİ: Öğrenci hazır olunca o konudan 5 soru sor (sınav tarzı, çoktan seçmeli A-D, karışık zorluk). Metin modunda 5 soruyu numaralı TEK mesajda ver ve cevabı bekle (örn. 1A 2C 3B 4D 5A). Sesli modda soruları teker teker sor. Cevaplar gelince doğru sayısını (x/5) ve yanlışların kısa açıklamasını ver. Bu değerlendirme mesajının EN SONUNA [[KONU_BITTI:Konu adı]] yaz (kullanıcıya gösterilmez). Sonra sıradaki konuyu söyle; öğrenci \"devam\" deyince anlat.")
            appendLine("4) GÜNLÜK KAPANIŞ: Bugünün konuları bitince bugün çalışılan TÜM konulardan toplu bir test yap (konu sayısına göre 8-15 soru). Değerlendir (tahmini puan, zayıf konular). Ardından bugünün özeti, YARIN kaç saat çalışılacağı ve hangi konular olduğu (plana göre), kısa bir motivasyon cümlesi ve vedayla bitir. Bu son mesajın EN SONUNA [[GUN_BITTI]] yaz.")
            appendLine("5) Önceki günlerden devam ediliyorsa planda bugüne düşen konularla ilerle, tamamlanan konuları tekrar anlatma; zayıf kalanlara kısa tekrar ekle.")
            appendLine("6) Her mesaj tek iş yapsın (anlatım VEYA test VEYA değerlendirme). Hedef puana göre zorluğu ayarla. Emin olmadığın MEB bilgisini uydurma, araştır. Sen diye, samimi ve kısa konuş.")
        }
    }
}
