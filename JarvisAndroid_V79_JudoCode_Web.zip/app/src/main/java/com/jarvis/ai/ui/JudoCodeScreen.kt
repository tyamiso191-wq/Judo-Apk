package com.jarvis.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.code.CodeEvent
import com.jarvis.ai.code.CodeEventKind
import com.jarvis.ai.theme.*

/** Judo Code: kodlama ajanı ekranı (Claude Code tarzı). Araç çağrıları sohbet akışında görünür. */
@Composable
fun JudoCodeScreen(
    events: List<CodeEvent>,
    busy: Boolean,
    onSend: (String) -> Unit,
    onStop: () -> Unit,
    onClear: () -> Unit,
    onClose: () -> Unit,
    onSaveFile: (com.jarvis.ai.files.FileTool.StagedFile) -> Unit = {}
) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(events.size) {
        if (events.isNotEmpty()) listState.animateScrollToItem(events.lastIndex)
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().imePadding()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().background(Panel).padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("JUDO CODE", color = Teal, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp, fontFamily = FontFamily.Monospace)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("TEMİZLE", color = Dim, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.clickable(enabled = !busy, onClick = onClear)
                        .background(Dim.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp))
                Text("KAPAT", color = Dim, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.clickable(onClick = onClose)
                        .background(Dim.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp))
            }
        }

        Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            Text("Web erişimi var  •  klasör: terminal ile ortak  •  derleyici/gradle yok",
                color = Dim, fontSize = 10.sp, fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 8.dp))

            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth()
                    .border(1.dp, TealDim.copy(alpha = 0.35f)).padding(10.dp)
            ) {
                items(events) { e ->
                    Column(Modifier.padding(bottom = 10.dp)) {
                        when (e.kind) {
                            CodeEventKind.USER -> Text("› ${e.text}", color = Teal, fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            CodeEventKind.ASSISTANT -> Text(e.text, color = Text, fontSize = 13.sp)
                            CodeEventKind.TOOL -> {
                                Text("⚙ ${e.text}", color = Dim, fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                if (e.file != null) {
                                    Text("📎 ${e.file.filename}  —  KAYDET", color = Teal, fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(top = 4.dp)
                                            .clickable { onSaveFile(e.file) }
                                            .background(Teal.copy(alpha = 0.12f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 10.dp, vertical = 6.dp))
                                }
                                if (!e.detail.isNullOrBlank()) {
                                    Text(e.detail, color = Dim.copy(alpha = 0.8f), fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace, maxLines = 6)
                                }
                            }
                            CodeEventKind.ERROR -> Text(e.text, color = Color(0xFFFF6B6B), fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace)
                        }
                    }
                }
                if (busy) item {
                    Text("çalışıyor…", color = Teal.copy(alpha = 0.7f), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }

            Spacer(Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    placeholder = { Text("ne yapayım? (örn. şu PDF'i bul, hesap makinesi yaz)", color = Dim,
                        fontFamily = FontFamily.Monospace, fontSize = 12.sp) },
                    maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Teal, unfocusedBorderColor = TealDim,
                        focusedTextColor = Text, unfocusedTextColor = Text, cursorColor = Teal
                    ),
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, fontFamily = FontFamily.Monospace),
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(6.dp))
                IconButton(
                    onClick = {
                        if (busy) onStop() else if (input.isNotBlank()) { onSend(input.trim()); input = "" }
                    },
                    modifier = Modifier.size(42.dp).background(if (busy) Color(0xFFFF6B6B) else Teal, RoundedCornerShape(8.dp))
                ) {
                    Text(if (busy) "■" else "➤", color = Bg, fontSize = 16.sp)
                }
            }
        }
    }
}
