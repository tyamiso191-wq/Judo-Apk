# Jarvis V67 — OpenRouter + Adaptive Multi-Agent

## Kurulum
1. Android Studio'da projeyi aç, Gradle senkronize et (yeni bağımlılık yok; yalnızca test bağımlılıkları eklendi).
2. İmza şifresi kodda DEĞİL: `JARVIS_KEYSTORE_PASSWORD` ortam değişkeni / Gradle özelliği olarak ver (bkz. `app/build.gradle.kts`).
3. Uygulamayı aç → **OpenRouter API anahtarı** ekranı gelir (https://openrouter.ai/keys). Tek anahtar yeter.
   Anahtar `GET /api/v1/key` ile doğrulanır; geçerliyse Android Keystore (AES-256-GCM) ile şifreli saklanır.
   Kayıtlı anahtar varsa tekrar sorulmaz. Anahtarı değiştirmek: ☰/Geçmiş paneli → **AI Ajanları** → *Anahtarı değiştir*.
4. Modeller `GET /api/v1/models` ile OpenRouter kataloğundan keşfedilir (12 saat önbellek). Model adı girmek gerekmez.

## Mimari (`app/src/main/java/com/jarvis/ai/agents/`)
| Bileşen | Dosya |
|---|---|
| Ana ajan / yönetici, Task Planner, Agent Manager, Quality Controller, Result Merger | `Orchestrator.kt`, `AgentPlan.kt`, `AgentRoles.kt` |
| AI Model Router (katalog verisinden puanlama, sabit model adı yok) | `ModelRouter.kt`, `ModelCatalog.kt`, `TaskAnalyzer.kt` |
| Provider Manager (tek sağlayıcı: OpenRouter), sağlık/devre kesici | `OpenRouterClient.kt`, `HealthTracker.kt` |
| Fallback Manager (hata türüne göre yedek model) | `FallbackRunner.kt`, `ErrorClassifier.kt` |
| Gerçek token / maliyet defteri, olay kaydı | `UsageLedger.kt`, `LlmCaller.kt`, `EventLog.kt` |
| Ayarlar, güvenli anahtar deposu, bağlama | `AgentSettings.kt`, `SecureKeyStore.kt`, `AiRuntime.kt` |

## Davranış
- **Sohbet / basit sorular**: yerel görev analizi (ek API çağrısı yok) → tek model; araç çağırma (cihaz fonksiyonları) desteği olan modeller seçilir.
- **Çoklu ajan**: yalnızca *karmaşık + cihaz eylemi içermeyen* kodlama/proje/araştırma/akıl yürütme görevlerinde.
  Planner (1 çağrı) → bağımsız ajanlar `async` + `Semaphore(maxConcurrent ≤ 10)` ile paralel, bağımlılar beklenir →
  kalite kontrol (≥3 başarılı ajan varsa; en fazla 1 tur, yalnızca yaprak ajanlar yeniden çalışır) → Jarvis tek yanıtta birleştirir.
- **Hata sınıfları** (birbirine karıştırılmaz): 401 anahtar · 402 kredi (Retry-After varsa geçici "in-flight" bütçesi) ·
  429 model/sağlayıcı limiti ↔ hesap (ücretsiz katman) limiti · bağlam aşımı (yalnızca daha geniş bağlamlı modele geçilir) ·
  404/uyumsuz model · geçici 5xx / ağ / zaman aşımı (aynı modelde tek yeniden deneme, sonra yedek).
  Toplam deneme sayısı sınırlıdır; hepsi tükenirse kullanıcıya açık mesaj verilir.
- **Kredi**: OpenRouter'da tüm modeller aynı hesaptan çekilir. Kredi bitince ücretli modellere geçmek işe yaramaz;
  yalnızca ücretsiz (`:free`) modeller bir kez denenir (onlar da hesap durumuna/limitlere bağlıdır).
- **Maliyet**: *Gerçekleşen* = OpenRouter'ın `usage.cost` değeri (yoksa gerçek token × katalog fiyatı, ayrı işaretlenir);
  kullanım bilgisi gelmeyen çağrılar "bilinmiyor" sayılır, tahminle doldurulmaz. *Tahmini* maliyet yalnızca çalışma öncesi kaba hesaptır ve ayrı gösterilir.
- **Güvenlik**: ajanlar cihaz araçlarına (telefon, dosya, terminal) erişemez; yalnızca Research ajanı salt-okunur web araçlarını kullanır.
  Ajan çıktıları ve web içeriği "veri" olarak işaretlenir. Kullanıcı onayı gerektiren eylemler yalnızca ana Jarvis yolundan geçer.

## Testler
`./gradlew :app:testDebugUnitTest` — **MOCK** taşıyıcıyla çalışır, canlı OpenRouter çağrısı yapmaz.
Canlı doğrulama için gerçek bir anahtarla uygulamada denemek gerekir.
