package com.jarvis.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.KeyCheckState
import com.jarvis.ai.theme.*

@Composable
fun ApiKeyScreen(
    onSave: (String) -> Unit,
    checkState: KeyCheckState = KeyCheckState.Idle
) {
    var key by remember { mutableStateOf("") }
    val uriHandler = LocalUriHandler.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(24.dp))
                .padding(28.dp)
        ) {
            Text(
                text = "◈ Judo",
                color = Teal,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 4.sp,
                fontFamily = UiFont
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = "Başlamak için Google Gemini API anahtarını gir. Anahtarı Google AI Studio'dan ücretsiz alabilirsin.",
                color = Dim,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                fontFamily = UiFont
            )
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(
                value = key,
                onValueChange = { key = it },
                placeholder = {
                    Text("Gemini API anahtarı (AIza…)", color = Dim, fontFamily = UiFont)
                },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Teal,
                    unfocusedBorderColor = TealDim,
                    focusedTextColor = Text,
                    unfocusedTextColor = Text,
                    cursorColor = Teal
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(20.dp))
            Button(
                enabled = checkState !is KeyCheckState.Checking,
                onClick = { if (key.isNotBlank()) onSave(key.trim()) },
                colors = ButtonDefaults.buttonColors(containerColor = Teal, contentColor = Bg),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text(
                    if (checkState is KeyCheckState.Checking) "DOĞRULANIYOR…" else "DOĞRULA VE BAŞLAT",
                    fontFamily = UiFont,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            }
            if (checkState is KeyCheckState.Error) {
                Spacer(Modifier.height(12.dp))
                Text(
                    text = checkState.message,
                    color = Red,
                    fontSize = 12.sp,
                    fontFamily = UiFont,
                    textAlign = TextAlign.Center
                )
            }
            Spacer(Modifier.height(16.dp))
            Text(
                text = "Anahtar al: aistudio.google.com/apikey",
                color = Teal,
                fontSize = 11.sp,
                fontFamily = UiFont,
                textAlign = TextAlign.Center,
                modifier = Modifier.clickable { uriHandler.openUri("https://aistudio.google.com/apikey") }
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Anahtar doğrulanır ve yalnızca bu telefonda, Android Keystore ile şifreli saklanır. Kullanımın Google hesabındaki Gemini kotasına yazılır (ücretsiz katmanın günlük/dakikalık sınırları vardır).",
                color = Dim.copy(alpha = 0.7f),
                fontSize = 10.sp,
                fontFamily = UiFont,
                textAlign = TextAlign.Center
            )
        }
    }
}
