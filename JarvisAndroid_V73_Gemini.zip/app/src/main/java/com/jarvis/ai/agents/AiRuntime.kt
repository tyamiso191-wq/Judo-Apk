package com.jarvis.ai.agents

import android.content.Context
import com.jarvis.ai.web.WebSearchClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File

class FileTextStore(private val file: File) : TextStore {
    override fun load(): String? = try { if (file.exists()) file.readText() else null } catch (e: Exception) { null }
    override fun save(text: String) {
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(file)) { file.writeText(text); tmp.delete() }
    }
}

private class FileCatalogStorage(ctx: Context) : CatalogStorage {
    private val file = FileTextStore(File(ctx.filesDir, "ai_models.json"))
    private val prefs = ctx.getSharedPreferences("jarvis_catalog", Context.MODE_PRIVATE)
    override fun load(): String? = file.load()
    override fun save(json: String) = file.save(json)
    override fun lastFetchMs(): Long = prefs.getLong("last", 0L)
    override fun setLastFetchMs(ms: Long) { prefs.edit().putLong("last", ms).apply() }
}

/**
 * Tüm yapay zekâ altyapısının tek sahibi (uygulama genelinde tek örnek). Ana sohbet,
 * arka plan servisi ve çoklu ajan sistemi AYNI OpenRouter anahtarını, sağlık/kota durumunu
 * ve kullanım defterini paylaşır.
 */
class AiRuntime private constructor(ctx: Context) {
    private val appCtx = ctx.applicationContext
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val keyStore = SecureKeyStore(appCtx)

    private val settingsPrefs = appCtx.getSharedPreferences("jarvis_agent_settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(AgentSettings.fromJson(settingsPrefs.getString("json", null)))
    val settings: StateFlow<AgentSettings> = _settings.asStateFlow()

    fun updateSettings(f: (AgentSettings) -> AgentSettings) {
        val n = f(_settings.value).normalized()
        _settings.value = n
        settingsPrefs.edit().putString("json", n.toJson()).apply()
    }

    val events = EventLog(store = FileTextStore(File(appCtx.filesDir, "ai_events.json")), scope = scope)
    val ledger = UsageLedger(FileTextStore(File(appCtx.filesDir, "ai_usage.json")), scope)
    val health = HealthTracker()
    val openRouter = OpenRouterClient({ keyStore.get() })
    val catalog = ModelCatalog({ openRouter.fetchModels() }, FileCatalogStorage(appCtx), events)
    val router = ModelRouter()
    val runner = FallbackRunner(health, events, keyStillValid = { openRouter.validateKey() is KeyStatus.Valid })
    val caller = LlmCaller(openRouter, ledger)

    /** Ana sohbet için Gemini API geçidi (aynı anahtar deposunu kullanır). */
    val gemini = GeminiClient({ keyStore.get() })
    val geminiCaller = LlmCaller(gemini, ledger)

    /** Çoklu ajanlara verilen TEK araç seti: salt-okunur web arama / sayfa okuma. */
    private val webTools: WebToolExecutor = { name, args ->
        withContext(Dispatchers.IO) {
            when (name) {
                "web_search" -> WebSearchClient.search(args.optString("query")).toString()
                "read_webpage" -> WebSearchClient.readPage(args.optString("url")).toString()
                else -> "Bilinmeyen araç"
            }
        }
    }

    val orchestrator = Orchestrator(
        caller = caller,
        catalog = { catalog.getModels() },
        router = router,
        health = health,
        runner = runner,
        events = events,
        ledger = ledger,
        settings = { _settings.value },
        webTools = webTools
    )

    /** Ana Judo sohbeti için sıralı aday modeller (araç çağırma desteği şart). */
    suspend fun chatCandidates(profile: TaskProfile): List<ModelInfo> {
        if (health.authBroken) {
            throw AiUnavailableException(
                "OpenRouter API anahtarı geçersiz ya da erişim reddedildi. Ayarlardan anahtarı yenile.",
                listOf(ErrorKind.AUTH)
            )
        }
        val models = catalog.getModels()
        return router.rank(profile, models, health, _settings.value)
    }

    companion object {
        @Volatile private var instance: AiRuntime? = null

        fun get(ctx: Context): AiRuntime =
            instance ?: synchronized(this) { instance ?: AiRuntime(ctx).also { instance = it } }
    }
}
