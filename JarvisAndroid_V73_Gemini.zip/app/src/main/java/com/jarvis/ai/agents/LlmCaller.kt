package com.jarvis.ai.agents

import kotlinx.coroutines.CancellationException
import org.json.JSONObject

data class CallContext(val taskId: String, val agentId: String, val purpose: String)

data class LlmReply(
    val message: JSONObject,
    val finishReason: String?,
    val usage: TokenUsage,
    val modelId: String
)

/**
 * Tek bir OpenRouter çağrısı: isteği gönderir, hatayı sınıflandırır, GERÇEK kullanım
 * (usage.prompt_tokens / completion_tokens / cost) verisini deftere yazar. Kullanım bilgisi
 * gelmezse tahmin üretilip gerçekmiş gibi gösterilmez (UNKNOWN olarak işaretlenir).
 */
class LlmCaller(
    private val transport: ChatTransport,
    private val ledger: UsageLedger,
    private val now: () -> Long = System::currentTimeMillis
) {
    suspend fun complete(ctx: CallContext, model: ModelInfo, body: JSONObject): LlmReply {
        body.put("model", model.id)
        val estPrompt = (body.optJSONArray("messages")?.toString()?.length ?: 0) / 3
        val started = now()
        try {
            val raw = try {
                transport.post(body)
            } catch (e: CancellationException) {
                throw e
            } catch (e: LlmException) {
                throw e
            } catch (t: Throwable) {
                throw ErrorClassifier.classifyThrowable(t, model.id)
            }
            if (raw.code !in 200..299) {
                throw ErrorClassifier.classifyHttp(raw.code, raw.body, raw.retryAfterMs, model)
            }
            val json = try {
                JSONObject(raw.body)
            } catch (e: Exception) {
                throw LlmException(ErrorKind.EMPTY_RESPONSE, raw.code, null, "Geçersiz yanıt biçimi.", model.id)
            }
            val err = json.optJSONObject("error")
            if (err != null) {
                val code = err.optInt("code", 500).let { if (it in 100..599) it else 500 }
                throw ErrorClassifier.classifyHttp(code, raw.body, raw.retryAfterMs, model)
            }
            val choice = json.optJSONArray("choices")?.optJSONObject(0)
            val message = choice?.optJSONObject("message")
                ?: throw LlmException(ErrorKind.EMPTY_RESPONSE, raw.code, null, "Boş yanıt döndü.", model.id)
            val usage = parseUsage(json.optJSONObject("usage"), model)
            ledger.add(
                UsageRecord(
                    ts = now(), taskId = ctx.taskId, agentId = ctx.agentId, purpose = ctx.purpose,
                    modelId = model.id, promptTokens = usage.promptTokens, completionTokens = usage.completionTokens,
                    costUsd = usage.costUsd, costSource = usage.costSource, latencyMs = now() - started,
                    success = true, errorKind = null, estPromptTokens = estPrompt
                )
            )
            return LlmReply(message, choice.optString("finish_reason").ifBlank { null }, usage, model.id)
        } catch (e: LlmException) {
            ledger.add(
                UsageRecord(
                    ts = now(), taskId = ctx.taskId, agentId = ctx.agentId, purpose = ctx.purpose,
                    modelId = model.id, promptTokens = null, completionTokens = null, costUsd = null,
                    costSource = CostSource.UNKNOWN, latencyMs = now() - started, success = false,
                    errorKind = e.kind.name, estPromptTokens = estPrompt
                )
            )
            throw e
        }
    }

    private fun parseUsage(u: JSONObject?, model: ModelInfo): TokenUsage {
        if (u == null) return TokenUsage(null, null, null, CostSource.UNKNOWN)
        val p = if (u.has("prompt_tokens") && !u.isNull("prompt_tokens")) u.optInt("prompt_tokens") else null
        val c = if (u.has("completion_tokens") && !u.isNull("completion_tokens")) u.optInt("completion_tokens") else null
        val cost = if (u.has("cost") && !u.isNull("cost")) u.optDouble("cost") else null
        return when {
            cost != null -> TokenUsage(p, c, cost, CostSource.REPORTED)
            p != null && c != null ->
                TokenUsage(p, c, p * model.promptPrice + c * model.completionPrice, CostSource.COMPUTED)
            else -> TokenUsage(p, c, null, CostSource.UNKNOWN)
        }
    }
}
