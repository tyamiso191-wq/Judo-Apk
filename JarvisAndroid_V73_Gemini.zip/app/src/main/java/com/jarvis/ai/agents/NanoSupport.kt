package com.jarvis.ai.agents

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Gemini Nano'nun bu cihazdaki durumu. */
enum class NanoState { UNKNOWN, AVAILABLE, DOWNLOADABLE, DOWNLOADING, UNAVAILABLE }

/** Kullanıcıya gösterilecek bildirim metinleri (JVM'de test edilebilir). */
object NanoNotice {
    /** @return AVAILABLE/UNKNOWN için null (bildirim gerekmez). */
    fun messageFor(state: NanoState): String? = when (state) {
        NanoState.UNAVAILABLE ->
            "Bu cihaz Gemini Nano'yu desteklemiyor. Tüm işler OpenRouter üzerinden yapılacak."
        NanoState.DOWNLOADABLE ->
            "Gemini Nano bu cihazda kullanılabilir ama henüz indirilmedi. Şimdilik OpenRouter kullanılıyor."
        NanoState.DOWNLOADING ->
            "Gemini Nano indiriliyor. Hazır olana kadar OpenRouter kullanılıyor."
        NanoState.AVAILABLE, NanoState.UNKNOWN -> null
    }
}

/**
 * Gemini Nano kontrolü — şimdilik ML Kit KÜTÜPHANESİZ.
 *
 * ML Kit GenAI Prompt API (genai-prompt 1.0.0-beta4) Kotlin 2.3 ile derlenmiş; bu projede
 * Kotlin 2.0.21 olduğu için derlemeyi kırıyor. Kütüphane olmadan kesin kontrol yapılamaz,
 * bu yüzden yalnızca KESİN olan durum işaretlenir:
 *  - AICore (com.google.android.aicore) yüklü değilse Nano kullanılamaz -> UNAVAILABLE.
 *  - AICore yüklüyse Nano'nun gerçekten desteklenip desteklenmediği doğrulanamaz -> UNKNOWN
 *    (bildirim gösterilmez).
 * Kesin sonuç (AVAILABLE / DOWNLOADABLE / DOWNLOADING) için Kotlin 2.3'e geçilip ML Kit
 * kütüphanesi eklenmelidir.
 */
object NanoSupport {
    private const val AICORE_PACKAGE = "com.google.android.aicore"

    suspend fun check(context: Context): NanoState = withContext(Dispatchers.IO) {
        val installed = try {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(AICORE_PACKAGE, 0)
            true
        } catch (e: Exception) {
            false
        }
        if (installed) NanoState.UNKNOWN else NanoState.UNAVAILABLE
    }
}
