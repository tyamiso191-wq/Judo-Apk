package com.jarvis.ai.vision

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.util.Log
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * Windows Judo V3'teki analyze_screen aracının Android karşılığı.
 * Android'de ekran yakalama izni (MediaProjection) sohbet ortasında sessizce
 * alınamaz -- kullanıcının bir sistem dialog'unu onaylaması ŞART. Bu yüzden
 * (play_song/takvim izinleri gibi) bu izin de UYGULAMA AÇILIŞINDA bir kez
 * istenir (bkz. MainActivity) ve sonucu burada, süreç hayatta olduğu sürece
 * yeniden kullanılmak üzere saklanır. Kullanıcı reddederse analyze_screen
 * fonksiyonu net bir hata döner, uygulama kırılmaz.
 */
object ScreenVisionController {
    private const val TAG = "ScreenVisionController"

    @Volatile private var permissionResultCode: Int = Activity.RESULT_CANCELED
    @Volatile private var permissionData: Intent? = null

    val hasPermission: Boolean
        get() = permissionData != null && permissionResultCode == Activity.RESULT_OK

    /**
     * MainActivity bunu doldurur. Android 14+ (API 34) ekran yakalama iznini TEK KULLANIMLIK
     * yapıyor: her yakalamadan sonra izin yeniden istenmek zorunda. İzin yokken
     * captureJpeg bu işlevi çağırıp kullanıcıdan sistem penceresini onaylamasını bekler.
     */
    @Volatile var permissionRequester: (suspend () -> Boolean)? = null

    /** MainActivity ekranda görünürken true (onStart/onStop). Arka plandaysa izin bildirimle istenir. */
    @Volatile var appVisible: Boolean = false

    /** Arka Plan Modu servisi doldurur: uygulama ekranda değilken izni bildirim üzerinden ister. */
    @Volatile var backgroundRequester: (suspend () -> Boolean)? = null

    @Volatile private var pendingBackground: CompletableDeferred<Boolean>? = null

    fun completeBackgroundPermission(granted: Boolean) {
        pendingBackground?.complete(granted)
    }

    /**
     * Uygulama arkadayken izin ister: önce doğrudan şeffaf izin aktivitesini açmayı dener (Android
     * arka plandan aktivite açmayı genelde engeller), ardından yüksek öncelikli bir bildirim bırakır;
     * kullanıcı dokunup sistem penceresini onaylayınca devam eder. 40 sn içinde olmazsa false.
     */
    suspend fun requestPermissionFromBackground(context: Context): Boolean {
        val appContext = context.applicationContext
        val waiter = CompletableDeferred<Boolean>()
        pendingBackground = waiter
        val intent = Intent(appContext, ScreenPermissionActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_HISTORY)
        val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                nm.createNotificationChannel(
                    android.app.NotificationChannel(
                        "jarvis_screen_ask", "Ekran izni isteği",
                        android.app.NotificationManager.IMPORTANCE_HIGH
                    )
                )
            }
            val pi = android.app.PendingIntent.getActivity(
                appContext, 7002, intent,
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = androidx.core.app.NotificationCompat.Builder(appContext, "jarvis_screen_ask")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Judo ekranı görmek istiyor")
                .setContentText("Ekranını görebilmem için dokun ve izin ver.")
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            nm.notify(7002, n)
        } catch (e: Exception) {
            Log.w(TAG, "İzin bildirimi gösterilemedi", e)
        }
        try { appContext.startActivity(intent) } catch (e: Exception) { /* arka plan kısıtı: bildirim kalıyor */ }
        val granted = withTimeoutOrNull(40_000L) { waiter.await() } ?: false
        try { nm.cancel(7002) } catch (e: Exception) { }
        pendingBackground = null
        return granted
    }

    fun buildPermissionRequestIntent(context: Context): Intent {
        val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        return manager.createScreenCaptureIntent()
    }

    /** MainActivity'nin ActivityResultLauncher callback'inden çağrılır. */
    fun onPermissionResult(resultCode: Int, data: Intent?) {
        permissionResultCode = resultCode
        permissionData = data
    }

    /**
     * @return yakalanan ekran görüntüsünün JPEG bayt dizisi. İzin
     * verilmemişse ya da yakalama başarısız olursa null.
     */
    suspend fun captureJpeg(context: Context): ByteArray? {
        if (!hasPermission) {
            val requester = if (appVisible) permissionRequester else (backgroundRequester ?: permissionRequester)
            val granted = try { requester?.invoke() ?: false } catch (e: Exception) { false }
            if (!granted) {
                Log.w(TAG, "Ekran yakalama izni yok/verilmemiş.")
                return null
            }
        }
        val data = permissionData
        if (!hasPermission || data == null) {
            Log.w(TAG, "Ekran yakalama izni yok/verilmemiş.")
            return null
        }
        val appContext = context.applicationContext

        // Android 14+ şartı: MediaProjection SADECE mediaProjection türünde
        // bir foreground servis çalışırken kullanılabilir.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            appContext.startForegroundService(Intent(appContext, ScreenCaptureService::class.java))
            // Servisin startForeground()'u çağırması için kısa bir pay --
            // aksi halde getMediaProjection() "foreground service required"
            // hatası verebilir.
            delay(250)
        }

        val manager = appContext.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        var projection: MediaProjection? = null
        var virtualDisplay: VirtualDisplay? = null
        var imageReader: ImageReader? = null
        val handlerThread = HandlerThread("jarvis-screen-capture").apply { start() }
        return try {
            projection = manager.getMediaProjection(permissionResultCode, data)
            // Android 14+: aynı izin verisi ikinci kez kullanılamaz -- bir sonraki
            // yakalamada izin yeniden istenecek.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                permissionData = null
                permissionResultCode = Activity.RESULT_CANCELED
            }
            if (projection == null) {
                Log.w(TAG, "getMediaProjection null döndü.")
                return null
            }
            // Android 14+: createVirtualDisplay'den ÖNCE bir callback kaydedilmezse
            // IllegalStateException fırlatır ("Must register a callback before starting capture").
            projection.registerCallback(object : MediaProjection.Callback() {}, Handler(handlerThread.looper))

            val metrics: DisplayMetrics = appContext.resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi

            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            val handler = Handler(handlerThread.looper)

            val jpegBytes = suspendCoroutine<ByteArray?> { cont ->
                var resumed = false
                imageReader.setOnImageAvailableListener({ reader ->
                    if (resumed) return@setOnImageAvailableListener
                    val image = try { reader.acquireLatestImage() } catch (e: Exception) { null }
                    if (image == null) return@setOnImageAvailableListener
                    resumed = true
                    try {
                        val plane = image.planes[0]
                        val pixelStride = plane.pixelStride
                        val rowStride = plane.rowStride
                        val rowPadding = rowStride - pixelStride * width
                        val bitmap = Bitmap.createBitmap(
                            width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
                        )
                        bitmap.copyPixelsFromBuffer(plane.buffer)
                        val cropped = if (rowPadding == 0) bitmap else
                            Bitmap.createBitmap(bitmap, 0, 0, width, height)
                        val out = ByteArrayOutputStream()
                        cropped.compress(Bitmap.CompressFormat.JPEG, 85, out)
                        cont.resume(out.toByteArray())
                    } catch (e: Exception) {
                        Log.w(TAG, "Kare işlenemedi", e)
                        cont.resume(null)
                    } finally {
                        image.close()
                    }
                }, handler)

                virtualDisplay = projection.createVirtualDisplay(
                    "jarvis-screen-capture",
                    width, height, density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.surface, null, handler
                )
            }
            jpegBytes
        } catch (e: Exception) {
            Log.w(TAG, "Ekran yakalanamadı", e)
            null
        } finally {
            virtualDisplay?.release()
            imageReader?.close()
            projection?.stop()
            handlerThread.quitSafely()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                appContext.stopService(Intent(appContext, ScreenCaptureService::class.java))
            }
        }
    }
}
