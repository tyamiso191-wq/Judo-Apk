package com.jarvis.ai.automation

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Rect
import android.os.Build
import android.provider.Settings
import android.util.Log

/**
 * Hedef uygulamayı "küçük ekranda" açar:
 *   - DİKEY  : ekranın ÜST YARISI
 *   - YATAY  : ekranın ÇEYREĞİ (sol üst köşe)
 *
 * Android'de bir uygulamanın başka bir uygulamayı kendi içinde "pencere"
 * olarak göstermesine izin YOK; tek gerçek yol sistemin çoklu pencere
 * özellikleri. Bu yüzden sırayla şunlar denenir:
 *   1) FREEFORM: cihazda serbest pencere açıksa (Geliştirici seçenekleri >
 *      "Serbest biçimli pencereleri etkinleştir", Samsung/tablet vb.) uygulama
 *      TAM istenen boyutta (yarı/çeyrek) açılır.
 *   2) BÖLÜNMÜŞ EKRAN: erişilebilirlik servisiyle uygulama üste (yatayda
 *      sola) yaslanır, alta Judo gelir. Yatayda bu YARIM ekran olur (çeyrek
 *      değil) -- Android bölünmüş ekranı sadece yarı yarıya bölebiliyor.
 *   3) TAM EKRAN: ikisi de olmazsa uygulama tam ekran açılır, otomasyon yine
 *      çalışır.
 */
object MiniWindow {
    private const val TAG = "MiniWindow"

    enum class Layout(val label: String) {
        FREEFORM("freeform"), SPLIT("split_half"), FULLSCREEN("fullscreen")
    }

    @Volatile var splitActive: Boolean = false
        private set

    /** Bu oturumda serbest pencere bir kez başarısız olduysa tekrar bekleyip zaman kaybetme. */
    @Volatile private var freeformFailedOnce = false

    fun isLandscape(context: Context): Boolean =
        context.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    /** Dikey: üst yarı. Yatay: sol üst çeyrek. */
    fun targetBounds(context: Context): Rect {
        val dm = context.resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        return if (isLandscape(context)) Rect(0, 0, w / 2, h / 2) else Rect(0, 0, w, h / 2)
    }

    private fun freeformAvailable(context: Context): Boolean {
        val pm = context.packageManager
        val feature = pm.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)
        val enabled = try {
            Settings.Global.getInt(context.contentResolver, "enable_freeform_support", 0) == 1
        } catch (_: Exception) { false }
        return feature || enabled
    }

    fun launcherIntentFor(context: Context, pkg: String): Intent? =
        context.packageManager.getLaunchIntentForPackage(pkg)

    /** Paket yüklü mü? */
    fun isInstalled(context: Context, pkg: String): Boolean = try {
        context.packageManager.getPackageInfo(pkg, 0); true
    } catch (_: Exception) { false }

    /**
     * [intent] (zaten hedef paketi açacak şekilde hazırlanmış) küçük pencerede
     * açılır. Sonuç olarak gerçekten elde edilen düzeni döndürür.
     * IO thread'inde çağrılmalı (bekleme içerir).
     */
    fun launch(context: Context, intent: Intent, pkg: String): Layout {
        val svc = JarvisAccessibilityService.instance
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val screen = context.resources.displayMetrics

        // 1) Serbest (kayan) pencere: özellik bayrağı görünmese bile dene (bazı
        //    Xiaomi/Samsung sürümleri bayrağı bildirmeden destekliyor). Desteklenmiyorsa
        //    sistem bu isteği yok sayar ve aşağıdaki doğrulama başarısız olur.
        if (!freeformFailedOnce || freeformAvailable(context)) try {
            val opts = ActivityOptions.makeBasic().setLaunchBounds(targetBounds(context))
            val bundle = opts.toBundle()
            // 5 = WINDOWING_MODE_FREEFORM (ActivityOptions.KEY_LAUNCH_WINDOWING_MODE)
            bundle?.putInt("android.activity.windowingMode", 5)
            context.startActivity(intent, bundle)
            val wait = if (freeformAvailable(context)) 3000L else 1500L
            if (UiWait.until(wait) { isSmall(svc?.windowBounds(pkg), screen.heightPixels, screen.widthPixels) }) {
                return Layout.FREEFORM
            }
            freeformFailedOnce = true
        } catch (e: Exception) {
            Log.w(TAG, "Freeform açılış başarısız", e)
        }

        // 2) Bölünmüş ekran: önce uygulamayı tam ekran aç, sonra üste/sola yasla.
        if (svc != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                context.startActivity(intent)
                if (!UiWait.until(5000) { svc.rootFor(pkg) != null }) return Layout.FULLSCREEN
                // Zaten küçük pencerede (önceki komuttan kalma bölünmüş ekran) ise tekrar bölme.
                if (isSmall(svc.windowBounds(pkg), screen.heightPixels, screen.widthPixels)) {
                    return if (splitActive) Layout.SPLIT else Layout.FREEFORM
                }
                UiWait.sleep(250)
                svc.toggleSplitScreen()
                UiWait.sleep(600)
                // Boşta kalan yarıya Judo'i seç (Android 12+ "diğer uygulamayı seç" ekranı).
                pickJudoForOtherHalf(context, svc)
                val ok = UiWait.until(3000) {
                    isSmall(svc.windowBounds(pkg), screen.heightPixels, screen.widthPixels)
                }
                if (ok) { splitActive = true; return Layout.SPLIT }
            } catch (e: Exception) {
                Log.w(TAG, "Bölünmüş ekran başarısız", e)
            }
            return Layout.FULLSCREEN
        }

        // 3) Tam ekran
        try { context.startActivity(intent) } catch (e: Exception) { Log.w(TAG, "Açılamadı", e) }
        return Layout.FULLSCREEN
    }

    private fun pickJudoForOtherHalf(context: Context, svc: JarvisAccessibilityService) {
        val label = try {
            context.applicationInfo.loadLabel(context.packageManager).toString()
        } catch (_: Exception) { "Judo" }
        UiWait.until(2500) {
            for (root in svc.allRoots()) {
                val hit = svc.findAll(root) { n ->
                    svc.labelOf(n).contains(label, ignoreCase = true)
                }.firstOrNull { svc.click(it) }
                if (hit != null) return@until true
            }
            false
        }
    }

    private fun isSmall(b: Rect?, screenH: Int, screenW: Int): Boolean {
        if (b == null) return false
        return b.height() < screenH * 0.75 || b.width() < screenW * 0.75
    }

    /** Küçük pencereyi kapatır: bölünmüş ekrandaysa tek ekrana döner. */
    fun close(context: Context) {
        val svc = JarvisAccessibilityService.instance ?: return
        if (splitActive) {
            svc.toggleSplitScreen()
            splitActive = false
            UiWait.sleep(500)
        }
        // Judo'i öne getir.
        try {
            context.startActivity(
                Intent(context, com.jarvis.ai.MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            )
        } catch (_: Exception) { }
    }
}

/** Basit bekleme/yoklama yardımcıları (IO thread'inde kullanılır). */
object UiWait {
    fun sleep(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) { }
    }

    /** [cond] true dönene ya da süre bitene dek yoklar. İptal edilirse false. */
    fun until(timeoutMs: Long, stepMs: Long = 150, cond: () -> Boolean): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (JarvisAccessibilityService.cancelRequested) return false
            if (try { cond() } catch (_: Exception) { false }) return true
            sleep(stepMs)
        }
        return false
    }
}
