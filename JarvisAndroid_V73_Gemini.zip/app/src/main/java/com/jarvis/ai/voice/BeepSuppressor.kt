package com.jarvis.ai.voice

import android.content.Context
import android.media.AudioManager
import android.util.Log

/**
 * Android'in SpeechRecognizer'ı her dinleme başlarken/biterken "din din" diye bir
 * bip çalar (özellikle sürekli yeniden başlayan arka plan dinlemede çok rahatsız edici).
 * Bunu kapatmanın resmi bir yolu yok; bilinen yöntem, dinleme sürerken bildirim/sistem
 * (ve müzik çalmıyorsa medya) akışlarını geçici olarak susturmaktır.
 *
 * Güvenlik: sustururken hangi akışların kapatıldığı kalıcı olarak yazılır; uygulama bip
 * kapalıyken öldürülürse bir sonraki açılışta [restoreIfLeftover] ile geri açılır.
 * Zaten sessize alınmış akışlara dokunulmaz. Telefon (zil) akışına HİÇ dokunulmaz.
 */
object BeepSuppressor {
    private const val TAG = "BeepSuppressor"
    private const val PREFS = "beep_suppressor"
    private const val KEY = "muted_streams"

    private val lock = Any()
    private var active = false

    fun mute(context: Context) {
        synchronized(lock) {
            if (active) return
            val am = context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            val streams = mutableListOf(AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)
            // Müzik/video çalıyorsa medya akışını susturma (yoksa kullanıcının sesi kesilir).
            if (!am.isMusicActive) streams += AudioManager.STREAM_MUSIC
            val done = mutableListOf<Int>()
            for (s in streams) {
                try {
                    if (!am.isStreamMute(s)) {
                        am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, 0)
                        done += s
                    }
                } catch (e: Exception) {
                    // Rahatsız etmeyin modu vb. yüzünden SecurityException olabilir; yoksay.
                    Log.w(TAG, "mute($s)", e)
                }
            }
            if (done.isNotEmpty()) {
                active = true
                save(context, done)
            }
        }
    }

    fun unmute(context: Context) {
        synchronized(lock) {
            if (!active) return
            active = false
            restore(context)
        }
    }

    /** Süreç bip kapalıyken öldüyse (kalıcı kayıt kalmışsa) akışları geri açar. */
    fun restoreIfLeftover(context: Context) {
        synchronized(lock) {
            if (active) return
            restore(context)
        }
    }

    private fun restore(context: Context) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY, "").orEmpty()
        if (saved.isBlank()) return
        val am = context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (am != null) {
            saved.split(",").mapNotNull { it.trim().toIntOrNull() }.forEach { s ->
                try { am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0) }
                catch (e: Exception) { Log.w(TAG, "unmute($s)", e) }
            }
        }
        prefs.edit().remove(KEY).apply()
    }

    private fun save(context: Context, streams: List<Int>) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, streams.joinToString(",")).apply()
    }
}
