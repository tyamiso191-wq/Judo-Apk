package com.jarvis.ai.agents

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** OpenRouter /models yanıtını ve yerel önbelleği ModelInfo listesine çevirir. */
object ModelParser {

    fun parseApi(json: String, todayIso: String = today()): List<ModelInfo> {
        val data = JSONObject(json).optJSONArray("data") ?: return emptyList()
        val out = mutableListOf<ModelInfo>()
        for (i in 0 until data.length()) {
            val m = data.optJSONObject(i) ?: continue
            val id = m.optString("id")
            if (id.isBlank()) continue
            val pricing = m.optJSONObject("pricing") ?: continue
            val prompt = pricing.optString("prompt").toDoubleOrNull() ?: continue
            val completion = pricing.optString("completion").toDoubleOrNull() ?: continue
            // Negatif fiyat = değişken fiyatlı yönlendirici model (örn. otomatik yönlendirici): seçilemez.
            if (prompt < 0 || completion < 0) continue
            val top = m.optJSONObject("top_provider")
            val ctx = m.optInt("context_length", 0).takeIf { it > 0 } ?: top?.optInt("context_length", 0) ?: 0
            if (ctx <= 0) continue
            val arch = m.optJSONObject("architecture")
            val inputs = arch?.optJSONArray("input_modalities").toStrings()
            val outputs = arch?.optJSONArray("output_modalities").toStrings()
            if (outputs.isNotEmpty() && "text" !in outputs) continue
            val params = m.optJSONArray("supported_parameters").toStrings()
            val exp = if (m.isNull("expiration_date")) null else m.optString("expiration_date").takeIf { it.isNotBlank() }
            val maxComp = top?.let { if (it.isNull("max_completion_tokens")) null else it.optInt("max_completion_tokens", 0) }
                ?.takeIf { it > 0 }
            out += ModelInfo(
                id = id,
                name = m.optString("name", id),
                contextLength = ctx,
                maxCompletion = maxComp,
                promptPrice = prompt,
                completionPrice = completion,
                supportsTools = "tools" in params,
                supportsReasoning = "reasoning" in params || "include_reasoning" in params,
                supportsImages = "image" in inputs,
                created = m.optLong("created", 0L),
                expired = exp != null && exp.take(10) < todayIso
            )
        }
        return out.filterNot { it.expired }
    }

    fun toStored(list: List<ModelInfo>): String {
        val arr = JSONArray()
        list.forEach { m ->
            arr.put(
                JSONObject().put("id", m.id).put("name", m.name).put("ctx", m.contextLength)
                    .put("maxc", m.maxCompletion ?: 0).put("pp", m.promptPrice).put("cp", m.completionPrice)
                    .put("tools", m.supportsTools).put("reason", m.supportsReasoning)
                    .put("img", m.supportsImages).put("created", m.created)
            )
        }
        return arr.toString()
    }

    fun parseStored(json: String): List<ModelInfo> = try {
        val arr = JSONArray(json)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            ModelInfo(
                id = o.getString("id"), name = o.optString("name"), contextLength = o.optInt("ctx"),
                maxCompletion = o.optInt("maxc").takeIf { it > 0 },
                promptPrice = o.optDouble("pp"), completionPrice = o.optDouble("cp"),
                supportsTools = o.optBoolean("tools"), supportsReasoning = o.optBoolean("reason"),
                supportsImages = o.optBoolean("img"), created = o.optLong("created")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun JSONArray?.toStrings(): Set<String> {
        if (this == null) return emptySet()
        return (0 until length()).map { optString(it) }.toSet()
    }

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
}

interface CatalogStorage {
    fun load(): String?
    fun save(json: String)
    fun lastFetchMs(): Long
    fun setLastFetchMs(ms: Long)
}

/** Model kataloğu: OpenRouter'dan keşfedilir, 12 saat önbellekte tutulur; elle model adı gerekmez. */
class ModelCatalog(
    private val fetch: suspend () -> List<ModelInfo>,
    private val storage: CatalogStorage?,
    private val events: EventLog? = null,
    private val now: () -> Long = System::currentTimeMillis
) {
    companion object {
        const val TTL_MS = 12L * 3_600_000L
    }

    private val _models = MutableStateFlow(storage?.load()?.let { ModelParser.parseStored(it) } ?: emptyList())
    val models: StateFlow<List<ModelInfo>> = _models.asStateFlow()
    private val mutex = Mutex()

    fun find(id: String): ModelInfo? = _models.value.firstOrNull { it.id == id }

    /** Katalog boşsa ya da eskiyse yeniler; ağ hatasında eldeki (önbellek) listeyi korur. */
    suspend fun getModels(forceRefresh: Boolean = false): List<ModelInfo> {
        mutex.withLock {
            val stale = storage == null || now() - storage.lastFetchMs() > TTL_MS
            if (forceRefresh || _models.value.isEmpty() || stale) {
                try {
                    val fresh = fetch()
                    if (fresh.isNotEmpty()) {
                        _models.value = fresh
                        storage?.save(ModelParser.toStored(fresh))
                        storage?.setLastFetchMs(now())
                        events?.add(EventKind.INFO, "Model kataloğu güncellendi: ${fresh.size} model.")
                    }
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    events?.add(
                        EventKind.ERROR,
                        "Model kataloğu alınamadı (${Redactor.redact(e.message ?: "hata")}); eldeki liste kullanılıyor."
                    )
                }
            }
        }
        return _models.value
    }
}
