package com.jarvis.ai.agents

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

enum class CostSource {
    /** OpenRouter yanıtındaki usage.cost: gerçekten tahsil edilen tutar. */
    REPORTED,
    /** Yanıttaki GERÇEK token sayıları × katalog fiyatı (cost alanı gelmediyse). */
    COMPUTED,
    /** Kullanım bilgisi gelmedi: maliyet/token BİLİNMİYOR (tahminle doldurulmaz). */
    UNKNOWN
}

data class TokenUsage(
    val promptTokens: Int?,
    val completionTokens: Int?,
    val costUsd: Double?,
    val costSource: CostSource
)

data class UsageRecord(
    val ts: Long,
    val taskId: String,
    val agentId: String,
    val purpose: String,
    val modelId: String,
    val promptTokens: Int?,
    val completionTokens: Int?,
    val costUsd: Double?,
    val costSource: CostSource,
    val latencyMs: Long,
    val success: Boolean,
    val errorKind: String?,
    /** Çağrı öncesi kaba tahmin (yalnızca bütçe koruması için; gerçek tüketim DEĞİLDİR). */
    val estPromptTokens: Int
)

data class UsageSummary(
    val calls: Int = 0,
    val failedCalls: Int = 0,
    val promptTokens: Long = 0,
    val completionTokens: Long = 0,
    val costUsd: Double = 0.0,
    val reportedCostUsd: Double = 0.0,
    val computedCostUsd: Double = 0.0,
    /** Başarılı olup kullanım bilgisi gelmeyen çağrı sayısı. */
    val unknownUsageCalls: Int = 0
) {
    val totalTokens: Long get() = promptTokens + completionTokens
}

/** Görev / ajan / sağlayıcı / model bazında GERÇEK token ve maliyet kaydı. */
class UsageLedger(
    private val store: TextStore? = null,
    private val scope: CoroutineScope? = null,
    private val cap: Int = 1000
) {
    private val _records = MutableStateFlow(store?.load()?.let { parse(it) } ?: emptyList())
    val records: StateFlow<List<UsageRecord>> = _records.asStateFlow()
    private val savePending = AtomicBoolean(false)

    fun add(r: UsageRecord) {
        _records.update { (it + r).takeLast(cap) }
        scheduleSave()
    }

    fun clear() {
        _records.value = emptyList()
        scheduleSave()
    }

    fun summarize(filter: (UsageRecord) -> Boolean = { true }): UsageSummary =
        summarize(_records.value.filter(filter))

    fun taskSummary(taskId: String): UsageSummary = summarize { it.taskId == taskId }

    fun byModel(): List<Pair<String, UsageSummary>> =
        _records.value.groupBy { it.modelId }.map { it.key to summarize(it.value) }
            .sortedByDescending { it.second.costUsd }

    fun byAgent(): List<Pair<String, UsageSummary>> =
        _records.value.groupBy { it.agentId.substringBefore('#') }.map { it.key to summarize(it.value) }
            .sortedByDescending { it.second.totalTokens }

    /** Başarısızlık oranı ve ortalama gecikme (başarılı çağrılar) – izlenebilirlik için. */
    fun failureRate(): Double {
        val all = _records.value
        return if (all.isEmpty()) 0.0 else all.count { !it.success }.toDouble() / all.size
    }

    fun avgLatencyMs(): Long {
        val ok = _records.value.filter { it.success }
        return if (ok.isEmpty()) 0L else ok.sumOf { it.latencyMs } / ok.size
    }

    private fun summarize(list: List<UsageRecord>): UsageSummary {
        var s = UsageSummary()
        for (r in list) {
            s = s.copy(
                calls = s.calls + 1,
                failedCalls = s.failedCalls + if (r.success) 0 else 1,
                promptTokens = s.promptTokens + (r.promptTokens ?: 0),
                completionTokens = s.completionTokens + (r.completionTokens ?: 0),
                costUsd = s.costUsd + (r.costUsd ?: 0.0),
                reportedCostUsd = s.reportedCostUsd + if (r.costSource == CostSource.REPORTED) (r.costUsd ?: 0.0) else 0.0,
                computedCostUsd = s.computedCostUsd + if (r.costSource == CostSource.COMPUTED) (r.costUsd ?: 0.0) else 0.0,
                unknownUsageCalls = s.unknownUsageCalls + if (r.success && r.costSource == CostSource.UNKNOWN) 1 else 0
            )
        }
        return s
    }

    private fun scheduleSave() {
        val st = store ?: return
        val sc = scope ?: return
        if (savePending.compareAndSet(false, true)) {
            sc.launch {
                delay(1500)
                savePending.set(false)
                try { st.save(toJson(_records.value)) } catch (e: Exception) { /* bellekte kalır */ }
            }
        }
    }

    private fun toJson(list: List<UsageRecord>): String {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(
                JSONObject().put("ts", r.ts).put("task", r.taskId).put("agent", r.agentId)
                    .put("purpose", r.purpose).put("model", r.modelId)
                    .put("pt", r.promptTokens ?: JSONObject.NULL).put("ct", r.completionTokens ?: JSONObject.NULL)
                    .put("cost", r.costUsd ?: JSONObject.NULL).put("src", r.costSource.name)
                    .put("lat", r.latencyMs).put("ok", r.success).put("err", r.errorKind ?: JSONObject.NULL)
                    .put("est", r.estPromptTokens)
            )
        }
        return arr.toString()
    }

    private fun parse(json: String): List<UsageRecord> = try {
        val arr = JSONArray(json)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            UsageRecord(
                ts = o.optLong("ts"), taskId = o.optString("task"), agentId = o.optString("agent"),
                purpose = o.optString("purpose"), modelId = o.optString("model"),
                promptTokens = if (o.isNull("pt")) null else o.optInt("pt"),
                completionTokens = if (o.isNull("ct")) null else o.optInt("ct"),
                costUsd = if (o.isNull("cost")) null else o.optDouble("cost"),
                costSource = runCatching { CostSource.valueOf(o.optString("src")) }.getOrDefault(CostSource.UNKNOWN),
                latencyMs = o.optLong("lat"), success = o.optBoolean("ok"),
                errorKind = if (o.isNull("err")) null else o.optString("err"),
                estPromptTokens = o.optInt("est")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }
}
