package com.jarvis.ai.agents

import java.io.IOException

/** Judo'in bir isteği sınıflandırdığı görev türleri (model seçimi bunlara göre yapılır). */
enum class TaskType(val label: String) {
    CHAT("Sohbet"),
    CODING("Kodlama"),
    REASONING("Akıl yürütme"),
    RESEARCH("Araştırma"),
    WRITING("Yazım / özet"),
    REVIEW("Denetim"),
    VISION("Görsel analiz"),
    PROJECT("Büyük proje")
}

enum class Complexity { LOW, MEDIUM, HIGH }

/** Bir istek için yönlendiricinin bilmesi gerekenler. Token sayıları TAHMİNDİR (gerçek kullanım değil). */
data class TaskProfile(
    val type: TaskType,
    val complexity: Complexity = Complexity.LOW,
    val needsTools: Boolean = false,
    val needsImages: Boolean = false,
    val estimatedInputTokens: Int = 500,
    val expectedOutputTokens: Int = 800,
    /** Telefonu/dosyayı/terminali kullanan bir eylem mi? Öyleyse çoklu ajan YOLU KULLANILMAZ. */
    val deviceAction: Boolean = false
)

/** OpenRouter model kataloğundan gelen, yönlendirmede kullanılan alanlar. Fiyatlar USD/token. */
data class ModelInfo(
    val id: String,
    val name: String,
    val contextLength: Int,
    val maxCompletion: Int?,
    val promptPrice: Double,
    val completionPrice: Double,
    val supportsTools: Boolean,
    val supportsReasoning: Boolean,
    val supportsImages: Boolean,
    val created: Long,
    val expired: Boolean = false
) {
    val isFree: Boolean get() = promptPrice == 0.0 && completionPrice == 0.0
    val family: String get() = id.substringBefore('/')
}

/** Hata türleri: birbirine KARIŞTIRILMAZ, her biri farklı davranış tetikler. */
enum class ErrorKind(val label: String) {
    AUTH("API anahtarı geçersiz ya da erişim reddedildi"),
    CREDITS("hesapta kredi yok"),
    INFLIGHT_BUDGET("eşzamanlı istek bütçesi geçici olarak dolu"),
    RATE_LIMIT_MODEL("model/sağlayıcı hız sınırı"),
    RATE_LIMIT_ACCOUNT("hesap düzeyinde (ücretsiz katman) limit"),
    CONTEXT_TOO_LONG("bağlam penceresi aşıldı"),
    MODEL_UNAVAILABLE("model erişilebilir değil"),
    MODEL_INCOMPATIBLE("model gerekli özelliği desteklemiyor"),
    MODERATION("içerik sağlayıcı tarafından reddedildi"),
    TRANSIENT_SERVER("geçici sunucu hatası"),
    NETWORK("bağlantı hatası"),
    TIMEOUT("zaman aşımı"),
    EMPTY_RESPONSE("boş/geçersiz yanıt"),
    BAD_REQUEST("geçersiz istek"),
    CANCELLED("iptal edildi")
}

class LlmException(
    val kind: ErrorKind,
    val httpCode: Int?,
    val retryAfterMs: Long?,
    message: String,
    val modelId: String? = null,
    /** Günlük kota türü bir 429 mu? (kısa süre beklemek işe yaramaz) */
    val daily: Boolean = false
) : IOException(message)

/** Hiçbir model/yol kullanılamadığında kullanıcıya gösterilecek açık mesajı taşır. */
class AiUnavailableException(val userMessage: String, val kinds: List<ErrorKind>) : IOException(userMessage)

/** Kullanıcı görevi iptal etti. */
class TaskCancelledException(message: String = "Görev iptal edildi.") : IOException(message)

/** Hata metinlerinden / loglardan API anahtarı gibi sırları siler. */
object Redactor {
    private val patterns = listOf(
        Regex("sk-or-[A-Za-z0-9_\\-]{6,}"),
        Regex("AIza[0-9A-Za-z_\\-]{20,}"),
        Regex("(?i)bearer\\s+[A-Za-z0-9_\\-.]{12,}")
    )

    fun redact(text: String): String {
        var r = text
        for (p in patterns) r = p.replace(r, "[gizli]")
        return r
    }
}
