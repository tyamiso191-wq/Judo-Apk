package com.jarvis.ai.agents

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.URI
import java.net.URLDecoder
import kotlin.concurrent.thread

/** MOCK: canlı OpenRouter çağrısı yapmaz; yerel callback sunucusu gerçekten açılır. */
class OpenRouterOAuthTest {

    @Test
    fun pkceChallengeMatchesRfc7636Vector() {
        // RFC 7636, Ek B
        assertEquals(
            "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM",
            Pkce.challengeS256("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk")
        )
    }

    @Test
    fun verifierLengthAndCharset() {
        val v = Pkce.newVerifier()
        assertTrue(v.length in 43..128)
        assertTrue(v.all { it.isLetterOrDigit() || it == '-' || it == '_' })
    }

    @Test
    fun parserHandlesCodeDeniedAndNoise() {
        assertEquals(
            OAuthCallbackParser.Parsed.Code("abc 123"),
            OAuthCallbackParser.parse("GET /callback?code=abc%20123 HTTP/1.1")
        )
        assertEquals(
            OAuthCallbackParser.Parsed.Denied("access_denied"),
            OAuthCallbackParser.parse("GET /callback?error=access_denied HTTP/1.1")
        )
        assertEquals(OAuthCallbackParser.Parsed.Ignore, OAuthCallbackParser.parse("GET /favicon.ico HTTP/1.1"))
        assertEquals(OAuthCallbackParser.Parsed.Ignore, OAuthCallbackParser.parse("POST /callback?code=x HTTP/1.1"))
        assertEquals(OAuthCallbackParser.Parsed.Ignore, OAuthCallbackParser.parse(null))
    }

    private fun fakeHttp(status: Int, json: String, seenBody: (String) -> Unit = {}): OkHttpClient =
        OkHttpClient.Builder().addInterceptor(Interceptor { chain ->
            val buf = okio.Buffer()
            chain.request().body?.writeTo(buf)
            seenBody(buf.readUtf8())
            Response.Builder()
                .request(chain.request()).protocol(Protocol.HTTP_1_1)
                .code(status).message("x")
                .body(json.toResponseBody("application/json".toMediaType()))
                .build()
        }).build()

    /** openBrowser yerine: auth adresinden callback_url'i çıkarıp o porta kod ile gider. */
    private fun browserThatApproves(code: String): (String) -> Unit = { authUrl ->
        val q = URI(authUrl).rawQuery.split('&').associate {
            it.substringBefore('=') to URLDecoder.decode(it.substringAfter('='), "UTF-8")
        }
        assertEquals("S256", q["code_challenge_method"])
        assertTrue(!q["code_challenge"].isNullOrBlank())
        val cb = q.getValue("callback_url")
        thread {
            val u = java.net.URL("$cb?code=$code")
            (u.openConnection() as java.net.HttpURLConnection).apply { responseCode; disconnect() }
        }
    }

    @Test
    fun fullFlowReturnsKeyAndSendsVerifier() = runBlocking {
        var sent = ""
        val oauth = OpenRouterOAuth(
            appPackage = "com.jarvis.ai",
            http = fakeHttp(200, """{"key":"sk-or-v1-testkey"}""") { sent = it },
            timeoutMs = 10_000,
            mainDispatcher = Dispatchers.Unconfined
        )
        val r = oauth.authorize(browserThatApproves("CODE1"))
        assertEquals(OAuthResult.Success("sk-or-v1-testkey"), r)
        assertTrue(sent.contains("\"code\":\"CODE1\""))
        assertTrue(sent.contains("code_verifier"))
        assertTrue(sent.contains("S256"))
    }

    @Test
    fun rejectedCodeGivesFailure() = runBlocking {
        val oauth = OpenRouterOAuth(
            "com.jarvis.ai", fakeHttp(403, """{"error":"bad"}"""),
            timeoutMs = 10_000, mainDispatcher = Dispatchers.Unconfined
        )
        val r = oauth.authorize(browserThatApproves("BAD"))
        assertTrue(r is OAuthResult.Failure)
    }

    @Test
    fun timesOutWhenUserNeverApproves() = runBlocking {
        val oauth = OpenRouterOAuth(
            "com.jarvis.ai", fakeHttp(200, "{}"),
            timeoutMs = 1_500, mainDispatcher = Dispatchers.Unconfined
        )
        val r = oauth.authorize { /* tarayıcı açılmadı */ }
        assertTrue(r is OAuthResult.Failure)
    }
}
